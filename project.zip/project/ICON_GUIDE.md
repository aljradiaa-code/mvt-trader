# تعليمات بناء الأيقونة والشعار

## استخدام أداة أونلاين لإنشاء الشعار

### الخيار 1: استخدام Favicon Generator
1. اذهب إلى: https://www.favicon-generator.org/
2. أرفع صورة أو نص "MVT"
3. حمّل الملفات المختلفة

### الخيار 2: استخدام Logo.com
1. اذهب إلى: https://www.logo.com/
2. اختر "Trading" أو "Finance"
3. صمّم شعاراً يعكس الذكاء الاصطناعي

### الخيار 3: استخدام Canva
1. اذهب إلى: https://www.canva.com/
2. ابحث عن "Finance App Logo"
3. عدّل وحمّل

## الملفات المطلوبة

ضع الملفات التالية في مجلد `public/`:

```
public/
├── favicon.ico           (16x16، 32x32)
├── android-chrome-192x192.png
├── android-chrome-512x512.png
├── apple-touch-icon.png  (180x180)
└── icon.svg
```

## تحديث index.html

أضف في `<head>`:

```html
<link rel="icon" type="image/svg+xml" href="/icon.svg" />
<link rel="apple-touch-icon" href="/apple-touch-icon.png" />
```

## للتطبيق الأصلي (مراد):

### الألوان المقترحة:
- **الأساسي**: Blue Gradient (#2563EB → #0891B2)
- **النص**: White (#FFFFFF)
- **الخلفية**: Dark Slate (#0F172A)

### النمط:
- رسم بياني صاعد (📈) مع عنصر ذكاء اصطناعي
- أو نموذج عصبي بسيط (circles connected)

### الفونت:
- Sans-serif عصري (Poppins، Inter، SF Pro)
