export interface Candle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface Trade {
  id: string;
  entryPrice: number;
  exitPrice: number | null;
  quantity: number;
  entryTime: number;
  exitTime: number | null;
  profitLoss: number | null;
  profitLossPercent: number | null;
  rule: string;
  status: 'open' | 'closed';
  stopLoss: number;
  takeProfit: number;
}

export interface Rule {
  id: string;
  name: string;
  description: string;
  totalTrades: number;
  winTrades: number;
  lossTrades: number;
  winRate: number;
  avgProfit: number;
  avgLoss: number;
  totalProfit: number;
  created: number;
}

export interface BacktestResult {
  trades: Trade[];
  totalTrades: number;
  totalProfit: number;
  winRate: number;
  maxDrawdown: number;
  profitFactor: number;
  startDate: number;
  endDate: number;
  initialBalance: number;
}

export interface ApiConfig {
  provider: 'twelvedata' | 'binance' | 'yahoo';
  apiKey: string;
  enabled: boolean;
}

export interface AppSettings {
  balance: number;
  riskPercent: number;
  timeframes: number[];
  apis: ApiConfig[];
  modelUrl: string;
  githubToken: string;
}
