import React from 'react';
import { X, TrendingUp, TrendingDown } from 'lucide-react';
import { Trade } from '../types';

interface TradePanelProps {
  trades: Trade[];
  onCloseTrade: (tradeId: string) => void;
}

export default function TradePanel({ trades, onCloseTrade }: TradePanelProps) {
  const openTrades = trades.filter(t => t.status === 'open');

  return (
    <div className="bg-slate-700 p-4 rounded-lg border border-slate-600">
      <h2 className="text-lg font-bold mb-4 flex items-center gap-2">
        <TrendingUp size={20} />
        Open Trades ({openTrades.length})
      </h2>

      <div className="space-y-2 max-h-96 overflow-y-auto">
        {openTrades.length === 0 ? (
          <div className="text-center text-slate-400 py-8">
            No open trades
          </div>
        ) : (
          openTrades.map(trade => (
            <div
              key={trade.id}
              className="bg-slate-600 p-3 rounded border border-slate-500 text-sm"
            >
              <div className="flex justify-between items-start mb-2">
                <div className="flex items-center gap-2">
                  {trade.rule.includes('BUY') || trade.rule.includes('LONG') ? (
                    <TrendingUp size={16} className="text-green-400" />
                  ) : (
                    <TrendingDown size={16} className="text-red-400" />
                  )}
                  <span className="font-medium text-xs text-slate-300">{trade.rule}</span>
                </div>
                <button
                  onClick={() => onCloseTrade(trade.id)}
                  className="text-red-400 hover:text-red-300"
                >
                  <X size={14} />
                </button>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <span className="text-slate-400">Entry:</span>
                  <span className="ml-1 text-white">{trade.entryPrice.toFixed(5)}</span>
                </div>
                <div>
                  <span className="text-slate-400">TP:</span>
                  <span className="ml-1 text-green-400">{trade.takeProfit.toFixed(5)}</span>
                </div>
                <div>
                  <span className="text-slate-400">SL:</span>
                  <span className="ml-1 text-red-400">{trade.stopLoss.toFixed(5)}</span>
                </div>
                <div>
                  <span className="text-slate-400">QTY:</span>
                  <span className="ml-1 text-white">{trade.quantity}</span>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
