import React from 'react';
import { Rule } from '../types';
import { Activity } from 'lucide-react';

interface RulesPanelProps {
  rules: Rule[];
}

export default function RulesPanel({ rules }: RulesPanelProps) {
  if (rules.length === 0) {
    return null;
  }

  return (
    <div className="bg-slate-700 p-4 rounded-lg border border-slate-600 mt-6">
      <h2 className="text-lg font-bold mb-4 flex items-center gap-2">
        <Activity size={20} />
        Trading Rules Performance ({rules.length})
      </h2>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-slate-600">
              <th className="text-left py-2 px-3 text-slate-400">Rule Name</th>
              <th className="text-center py-2 px-3 text-slate-400">Trades</th>
              <th className="text-center py-2 px-3 text-slate-400">Win Rate</th>
              <th className="text-center py-2 px-3 text-slate-400">Total Profit</th>
            </tr>
          </thead>
          <tbody>
            {rules.map(rule => (
              <tr key={rule.id} className="border-b border-slate-600 hover:bg-slate-600">
                <td className="py-2 px-3 text-white font-medium text-xs">{rule.name}</td>
                <td className="text-center py-2 px-3 text-slate-300">{rule.totalTrades}</td>
                <td className="text-center py-2 px-3">
                  <span className={rule.winRate > 50 ? 'text-green-400' : 'text-red-400'}>
                    {rule.winRate.toFixed(1)}%
                  </span>
                </td>
                <td className="text-center py-2 px-3">
                  <span className={rule.totalProfit >= 0 ? 'text-green-400' : 'text-red-400'}>
                    ${rule.totalProfit.toFixed(2)}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
