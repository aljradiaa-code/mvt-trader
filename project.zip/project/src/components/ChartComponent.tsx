import React, { useEffect, useRef } from 'react';
import { createChart, ColorType, IChartApi } from 'lightweight-charts';
import candleBuffer from '../services/candleBuffer';

interface ChartComponentProps {
  timeframe: number;
  symbol: string;
}

export default function ChartComponent({ timeframe, symbol }: ChartComponentProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    // إنشاء الرسم البياني
    const chart = createChart(containerRef.current, {
      layout: {
        background: { type: ColorType.Solid, color: '#0f172a' },
        textColor: '#d1d5db',
      },
      width: containerRef.current.clientWidth,
      height: 400,
      timeScale: {
        timeVisible: true,
        secondsVisible: true,
      },
    });

    chartRef.current = chart;

    const candlestickSeries = chart.addCandlestickSeries({
      upColor: '#22c55e',
      downColor: '#ef4444',
      borderDownColor: '#ef4444',
      borderUpColor: '#22c55e',
      wickDownColor: '#ef4444',
      wickUpColor: '#22c55e',
    });

    // تحديث الرسم البياني بالبيانات
    const updateChart = () => {
      const candles = candleBuffer.getCandles(timeframe);
      if (candles.length > 0) {
        const candleData = candles.map(candle => ({
          time: candle.time,
          open: candle.open,
          high: candle.high,
          low: candle.low,
          close: candle.close,
        }));

        candlestickSeries.setData(candleData);
        chart.timeScale().fitContent();
      }
    };

    updateChart();

    // الاستجابة لتغيير حجم النافذة
    const handleResize = () => {
      if (containerRef.current) {
        chart.applyOptions({
          width: containerRef.current.clientWidth,
        });
      }
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      chart.remove();
    };
  }, [timeframe]);

  return (
    <div
      ref={containerRef}
      className="bg-slate-700 rounded-lg border border-slate-600 overflow-hidden"
      style={{ height: '400px' }}
    />
  );
}
