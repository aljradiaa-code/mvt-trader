import { useState, useEffect } from 'react';
import { Home, TrendingUp, BarChart3, Settings, Github } from 'lucide-react';
import LiveTradingPage from './pages/LiveTradingPage';
import BacktestPage from './pages/BacktestPage';
import StatisticsPage from './pages/StatisticsPage';
import SettingsPage from './pages/SettingsPage';
import GithubSyncPage from './pages/GithubSyncPage';

type PageType = 'home' | 'trading' | 'backtest' | 'statistics' | 'settings' | 'github';

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageType>('home');

  const handleNavigate = (page: string) => {
    setCurrentPage(page as PageType);
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'trading':
        return <LiveTradingPage onNavigate={handleNavigate} />;
      case 'backtest':
        return <BacktestPage onNavigate={handleNavigate} />;
      case 'statistics':
        return <StatisticsPage onNavigate={handleNavigate} />;
      case 'settings':
        return <SettingsPage onNavigate={handleNavigate} />;
      case 'github':
        return <GithubSyncPage onNavigate={handleNavigate} />;
      default:
        return <HomePage onNavigate={handleNavigate} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800">
      {currentPage !== 'home' && (
        <nav className="bg-slate-900 border-b border-slate-700">
          <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
            <div className="flex items-center gap-2 cursor-pointer" onClick={() => handleNavigate('home')}>
              <div className="w-8 h-8 bg-gradient-to-r from-blue-400 to-cyan-400 rounded-lg" />
              <span className="text-white font-bold">MVT-VRL Trader</span>
            </div>
          </div>
        </nav>
      )}

      {renderPage()}
    </div>
  );
}

function HomePage({ onNavigate }: { onNavigate: (page: string) => void }) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 text-white">
      {/* Header */}
      <div className="border-b border-slate-700 bg-gradient-to-r from-blue-600 to-cyan-600">
        <div className="max-w-7xl mx-auto px-4 py-16">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 bg-white rounded-lg" />
            <div>
              <h1 className="text-5xl font-bold">MVT-VRL Trader</h1>
              <p className="text-blue-100 mt-2">Multi-Timeframe Vision Reinforcement Learning Trading System</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 py-16">
        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          <FeatureCard
            icon={<TrendingUp size={32} />}
            title="Live Trading"
            description="Real-time multi-timeframe analysis with automatic trade execution"
            onClick={() => onNavigate('trading')}
          />
          <FeatureCard
            icon={<BarChart3 size={32} />}
            title="Backtesting"
            description="Test strategies on historical data with adjustable playback speed"
            onClick={() => onNavigate('backtest')}
          />
          <FeatureCard
            icon={<BarChart3 size={32} />}
            title="Statistics"
            description="Comprehensive analytics and trading rule performance tracking"
            onClick={() => onNavigate('statistics')}
          />
          <FeatureCard
            icon={<Settings size={32} />}
            title="Settings"
            description="Configure APIs, trading parameters, and model settings"
            onClick={() => onNavigate('settings')}
          />
          <FeatureCard
            icon={<Github size={32} />}
            title="GitHub Sync"
            description="Auto-sync trades and download updated models"
            onClick={() => onNavigate('github')}
          />
          <FeatureCard
            icon={<Home size={32} />}
            title="Documentation"
            description="Learn how to use all features of the trading system"
            onClick={() => {}}
          />
        </div>

        {/* How It Works */}
        <div className="bg-slate-700 p-8 rounded-lg border border-slate-600 mb-16">
          <h2 className="text-3xl font-bold mb-8">How It Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <StepCard step={1} title="Fetch Data" description="Real-time candles from TwelveData API" />
            <StepCard step={2} title="Analyze" description="4 timeframes (5M, 15M, 1H, 4H) analyzed simultaneously" />
            <StepCard step={3} title="Trade" description="Automatic buy/sell with SL/TP management" />
            <StepCard step={4} title="Sync" description="Upload results to GitHub, download updated model" />
          </div>
        </div>

        {/* Key Features */}
        <div className="bg-gradient-to-r from-blue-600 to-cyan-600 p-8 rounded-lg mb-16">
          <h2 className="text-3xl font-bold mb-6">Key Features</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FeatureList
              features={[
                'TensorFlow.js Neural Network',
                'Multi-Timeframe Analysis',
                'Autonomous Rule Generation',
                'Paper Trading Engine',
              ]}
            />
            <FeatureList
              features={[
                'CSV Backtesting Support',
                'Real-time Chart Visualization',
                'GitHub Integration',
                'Performance Analytics',
              ]}
            />
          </div>
        </div>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button
            onClick={() => onNavigate('trading')}
            className="bg-green-600 hover:bg-green-700 text-white px-8 py-4 rounded-lg text-lg font-bold transition"
          >
            Start Trading
          </button>
          <button
            onClick={() => onNavigate('backtest')}
            className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-lg text-lg font-bold transition"
          >
            Run Backtest
          </button>
          <button
            onClick={() => onNavigate('github')}
            className="bg-slate-700 hover:bg-slate-600 text-white px-8 py-4 rounded-lg text-lg font-bold transition border border-slate-600"
          >
            GitHub Sync
          </button>
        </div>
      </div>

      {/* Footer */}
      <div className="border-t border-slate-700 mt-16 pt-8 pb-8">
        <div className="max-w-7xl mx-auto px-4 text-center text-slate-400 text-sm">
          <p>MVT-VRL Trader - Autonomous Multi-Timeframe Trading System</p>
          <p className="mt-2">Powered by TensorFlow.js • Integrated with GitHub • API by TwelveData</p>
        </div>
      </div>
    </div>
  );
}

function FeatureCard({
  icon,
  title,
  description,
  onClick,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
  onClick: () => void;
}) {
  return (
    <div
      onClick={onClick}
      className="bg-slate-700 p-6 rounded-lg border border-slate-600 hover:border-blue-500 transition cursor-pointer hover:shadow-lg hover:shadow-blue-500/20"
    >
      <div className="text-blue-400 mb-4">{icon}</div>
      <h3 className="text-xl font-bold mb-2">{title}</h3>
      <p className="text-slate-400 text-sm">{description}</p>
    </div>
  );
}

function StepCard({ step, title, description }: { step: number; title: string; description: string }) {
  return (
    <div className="bg-slate-700 p-4 rounded-lg border border-slate-600 text-center">
      <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-3 text-2xl font-bold">
        {step}
      </div>
      <h4 className="font-bold mb-2">{title}</h4>
      <p className="text-sm text-slate-400">{description}</p>
    </div>
  );
}

function FeatureList({ features }: { features: string[] }) {
  return (
    <ul className="space-y-3">
      {features.map((feature, index) => (
        <li key={index} className="flex items-center gap-3">
          <div className="w-2 h-2 bg-white rounded-full flex-shrink-0" />
          <span>{feature}</span>
        </li>
      ))}
    </ul>
  );
}
