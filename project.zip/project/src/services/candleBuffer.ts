import { Candle } from '../types';

class CandleBuffer {
  private buffers: {[key: number]: Candle[]} = {};
  private maxSize = 50;

  initializeTimeframe(timeframe: number): void {
    if (!this.buffers[timeframe]) {
      this.buffers[timeframe] = [];
    }
  }

  addCandle(timeframe: number, candle: Candle): void {
    this.initializeTimeframe(timeframe);
    this.buffers[timeframe].push(candle);

    if (this.buffers[timeframe].length > this.maxSize) {
      this.buffers[timeframe].shift();
    }
  }

  getCandles(timeframe: number): Candle[] {
    return this.buffers[timeframe] || [];
  }

  getLatestCandle(timeframe: number): Candle | null {
    const candles = this.getCandles(timeframe);
    return candles.length > 0 ? candles[candles.length - 1] : null;
  }

  setCandles(timeframe: number, candles: Candle[]): void {
    this.buffers[timeframe] = candles.slice(-this.maxSize);
  }

  clear(): void {
    this.buffers = {};
  }

  getAllTimeframes(): {[key: number]: Candle[]} {
    return this.buffers;
  }
}

export default new CandleBuffer();
