const TWELVEDATA_BASE_URL = 'https://api.twelvedata.com';

interface CandleResponse {
  status: string;
  datetime: string;
  open: string;
  high: string;
  low: string;
  close: string;
  volume: string;
}

export interface TimeSeriesResponse {
  meta: {
    symbol: string;
    interval: string;
    type: string;
    currency: string;
  };
  values: CandleResponse[];
  status: string;
}

export const fetchCandles = async (
  apiKey: string,
  symbol: string = 'EURUSD',
  interval: number = 5,
  limit: number = 50
): Promise<Array<{time: number, o: number, h: number, l: number, c: number, v: number}>> => {
  try {
    const intervalMap: {[key: number]: string} = {
      5: '5min',
      15: '15min',
      60: '1h',
      240: '4h',
      1440: '1day',
    };

    const intervalStr = intervalMap[interval] || '5min';

    const url = `${TWELVEDATA_BASE_URL}/time_series?symbol=${symbol}&interval=${intervalStr}&outputsize=${limit}&apikey=${apiKey}`;

    const response = await fetch(url);
    const data: TimeSeriesResponse = await response.json();

    if (data.status !== 'ok' || !data.values) {
      console.error('TwelveData API error:', data);
      return [];
    }

    return data.values.map((candle, index) => ({
      time: Date.parse(candle.datetime) / 1000,
      o: parseFloat(candle.open),
      h: parseFloat(candle.high),
      l: parseFloat(candle.low),
      c: parseFloat(candle.close),
      v: parseFloat(candle.volume),
    })).reverse();
  } catch (error) {
    console.error('Failed to fetch candles:', error);
    return [];
  }
};

export const fetchMultipleTimeframes = async (
  apiKey: string,
  symbol: string,
  timeframes: number[] = [5, 15, 60, 240]
): Promise<{[key: number]: Array<{time: number, o: number, h: number, l: number, c: number, v: number}>}> => {
  const results: {[key: number]: Array<{time: number, o: number, h: number, l: number, c: number, v: number}>} = {};

  for (const tf of timeframes) {
    results[tf] = await fetchCandles(apiKey, symbol, tf, 50);
    // تأخير صغير بين الطلبات لتجنب الحد من معدل الطلب
    await new Promise(resolve => setTimeout(resolve, 100));
  }

  return results;
};
