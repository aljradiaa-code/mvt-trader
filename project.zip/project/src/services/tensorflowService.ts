import * as tf from '@tensorflow/tfjs';

let model: tf.GraphModel | null = null;

export const loadModel = async (modelUrl: string): Promise<tf.GraphModel> => {
  try {
    model = await tf.loadGraphModel(modelUrl);
    console.log('Model loaded successfully');
    return model;
  } catch (error) {
    console.error('Failed to load model:', error);
    throw error;
  }
};

export const getModel = (): tf.GraphModel | null => {
  return model;
};

interface AnalysisResult {
  signal: 'buy' | 'sell' | 'hold';
  confidence: number;
  strength: number;
}

export const analyzeCandles = async (candles: Array<{o: number, h: number, l: number, c: number, v: number}>): Promise<AnalysisResult> => {
  if (!model) {
    return { signal: 'hold', confidence: 0, strength: 0 };
  }

  try {
    // تحضير البيانات - تحويل الشموع إلى متجهات بصرية
    const prepared = prepareInput(candles);

    // تشغيل النموذج
    const prediction = model.predict(prepared) as tf.Tensor;
    const data = await prediction.data();

    // معالجة النتيجة
    const signal = data[0] > 0.5 ? 'buy' : data[0] < -0.5 ? 'sell' : 'hold';
    const confidence = Math.abs(data[0]);
    const strength = Math.abs(data[1] || 0);

    prediction.dispose();
    prepared.dispose();

    return { signal, confidence, strength };
  } catch (error) {
    console.error('Analysis error:', error);
    return { signal: 'hold', confidence: 0, strength: 0 };
  }
};

const prepareInput = (candles: Array<{o: number, h: number, l: number, c: number, v: number}>): tf.Tensor => {
  // تحويل بيانات الشموع إلى مصفوفة 50x5
  const data: number[] = [];

  for (let i = 0; i < Math.min(50, candles.length); i++) {
    const candle = candles[i];
    data.push(candle.o, candle.h, candle.l, candle.c, candle.v);
  }

  // ملء بالأصفار إذا كان أقل من 50 شمعة
  while (data.length < 250) {
    data.push(0);
  }

  return tf.tensor2d([data.slice(0, 250)], [1, 250]);
};

export const generateRuleName = (signal: string, timeframes: number[]): string => {
  const timestamp = Date.now().toString().slice(-6);
  const strength = signal === 'buy' ? 'LONG' : signal === 'sell' ? 'SHORT' : 'HOLD';
  return `Rule_${strength}_${timeframes.join('_')}_${timestamp}`;
};
