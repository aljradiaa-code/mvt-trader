import { Trade, Rule } from '../types';
import { v4 as uuidv4 } from 'crypto';

class TradeManager {
  private trades: Trade[] = [];
  private rules: {[key: string]: Rule} = {};

  addTrade(trade: Omit<Trade, 'id'>): Trade {
    const newTrade: Trade = {
      ...trade,
      id: Math.random().toString(36).substr(2, 9),
    };
    this.trades.push(newTrade);
    this.saveTrades();
    return newTrade;
  }

  closeTrade(tradeId: string, exitPrice: number, exitTime: number): void {
    const trade = this.trades.find(t => t.id === tradeId);
    if (trade && trade.status === 'open') {
      trade.exitPrice = exitPrice;
      trade.exitTime = exitTime;
      trade.status = 'closed';
      trade.profitLoss = (exitPrice - trade.entryPrice) * trade.quantity;
      trade.profitLossPercent = ((exitPrice - trade.entryPrice) / trade.entryPrice) * 100;

      this.updateRuleStats(trade);
      this.saveTrades();
    }
  }

  private updateRuleStats(trade: Trade): void {
    if (!this.rules[trade.rule]) {
      this.rules[trade.rule] = {
        id: trade.rule,
        name: trade.rule,
        description: '',
        totalTrades: 0,
        winTrades: 0,
        lossTrades: 0,
        winRate: 0,
        avgProfit: 0,
        avgLoss: 0,
        totalProfit: 0,
        created: Date.now(),
      };
    }

    const rule = this.rules[trade.rule];
    rule.totalTrades++;

    if (trade.profitLoss! > 0) {
      rule.winTrades++;
    } else if (trade.profitLoss! < 0) {
      rule.lossTrades++;
    }

    rule.winRate = (rule.winTrades / rule.totalTrades) * 100;
    rule.totalProfit += trade.profitLoss || 0;
    rule.avgProfit = rule.winTrades > 0 ? rule.totalProfit / rule.winTrades : 0;
    rule.avgLoss = rule.lossTrades > 0 ? (rule.totalProfit - rule.totalProfit) / rule.lossTrades : 0;

    this.saveRules();
  }

  getTrades(): Trade[] {
    return this.trades;
  }

  getOpenTrades(): Trade[] {
    return this.trades.filter(t => t.status === 'open');
  }

  getClosedTrades(): Trade[] {
    return this.trades.filter(t => t.status === 'closed');
  }

  getRules(): Rule[] {
    return Object.values(this.rules);
  }

  getRule(ruleName: string): Rule | null {
    return this.rules[ruleName] || null;
  }

  private saveTrades(): void {
    localStorage.setItem('trades', JSON.stringify(this.trades));
  }

  private saveRules(): void {
    localStorage.setItem('rules', JSON.stringify(this.rules));
  }

  loadFromStorage(): void {
    const trades = localStorage.getItem('trades');
    const rules = localStorage.getItem('rules');

    if (trades) this.trades = JSON.parse(trades);
    if (rules) this.rules = JSON.parse(rules);
  }

  clear(): void {
    this.trades = [];
    this.rules = {};
    localStorage.removeItem('trades');
    localStorage.removeItem('rules');
  }
}

export default new TradeManager();
