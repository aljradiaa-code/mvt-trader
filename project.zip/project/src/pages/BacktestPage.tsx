import React, { useState, useRef } from 'react';
import { Upload, Play, Pause, RotateCcw, BarChart3 } from 'lucide-react';
import { BacktestResult, Trade, Candle } from '../types';
import { analyzeCandles } from '../services/tensorflowService';
import ChartComponent from '../components/ChartComponent';
import candleBuffer from '../services/candleBuffer';

interface BacktestPageProps {
  onNavigate: (page: string) => void;
}

export default function BacktestPage({ onNavigate }: BacktestPageProps) {
  const [file, setFile] = useState<File | null>(null);
  const [result, setResult] = useState<BacktestResult | null>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [speed, setSpeed] = useState(1);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFile = event.target.files?.[0];
    if (uploadedFile) {
      setFile(uploadedFile);
    }
  };

  const parseCSV = (content: string): Candle[] => {
    const lines = content.trim().split('\n');
    const candles: Candle[] = [];

    for (let i = 1; i < lines.length; i++) {
      const parts = lines[i].split(',');
      if (parts.length >= 5) {
        candles.push({
          time: Math.floor(new Date(parts[0]).getTime() / 1000),
          open: parseFloat(parts[1]),
          high: parseFloat(parts[2]),
          low: parseFloat(parts[3]),
          close: parseFloat(parts[4]),
          volume: parseFloat(parts[5] || '0'),
        });
      }
    }

    return candles;
  };

  const runBacktest = async () => {
    if (!file) return;

    try {
      setIsRunning(true);
      const content = await file.text();
      const candles = parseCSV(content);

      const trades: Trade[] = [];
      let balance = 10000;
      const startTime = Date.now();

      for (let i = 50; i < candles.length; i++) {
        const current50 = candles.slice(i - 50, i);
        const candleData = current50.map(c => ({
          o: c.open,
          h: c.high,
          l: c.low,
          c: c.close,
          v: c.volume,
        }));

        // تحليل البيانات
        const analysis = await analyzeCandles(candleData);

        if (analysis.signal !== 'hold' && analysis.confidence > 0.7) {
          const latestCandle = current50[current50.length - 1];
          const quantity = (balance * 0.02) / latestCandle.close;

          const trade: Trade = {
            id: `BT_${i}_${Math.random()}`,
            entryPrice: latestCandle.close,
            quantity: quantity,
            entryTime: latestCandle.time,
            rule: `Rule_${analysis.signal.toUpperCase()}_BT`,
            status: 'closed',
            stopLoss: analysis.signal === 'buy'
              ? latestCandle.close - (latestCandle.high - latestCandle.low)
              : latestCandle.close + (latestCandle.high - latestCandle.low),
            takeProfit: analysis.signal === 'buy'
              ? latestCandle.close + (latestCandle.high - latestCandle.low) * 2
              : latestCandle.close - (latestCandle.high - latestCandle.low) * 2,
            exitPrice: null,
            exitTime: null,
            profitLoss: null,
            profitLossPercent: null,
          };

          // محاكاة الخروج من الصفقة
          let exited = false;
          for (let j = i + 1; j < candles.length && !exited; j++) {
            const nextCandle = candles[j];

            if (
              (analysis.signal === 'buy' && nextCandle.high >= trade.takeProfit) ||
              (analysis.signal === 'sell' && nextCandle.low <= trade.takeProfit)
            ) {
              trade.exitPrice = trade.takeProfit;
              exited = true;
            } else if (
              (analysis.signal === 'buy' && nextCandle.low <= trade.stopLoss) ||
              (analysis.signal === 'sell' && nextCandle.high >= trade.stopLoss)
            ) {
              trade.exitPrice = trade.stopLoss;
              exited = true;
            }

            if (exited) {
              trade.exitTime = nextCandle.time;
              trade.profitLoss = (trade.exitPrice! - trade.entryPrice) * trade.quantity;
              trade.profitLossPercent = ((trade.exitPrice! - trade.entryPrice) / trade.entryPrice) * 100;
              balance += trade.profitLoss;
              trades.push(trade);
            }
          }
        }

        // تحديث التقدم
        setProgress(Math.round((i / candles.length) * 100));

        // تأخير بناءً على السرعة
        await new Promise(resolve => setTimeout(resolve, 100 / speed));
      }

      // حساب الإحصائيات
      const closedTrades = trades.filter(t => t.status === 'closed');
      const winTrades = closedTrades.filter(t => t.profitLoss! > 0).length;
      const totalProfit = closedTrades.reduce((sum, t) => sum + (t.profitLoss || 0), 0);

      setResult({
        trades: trades,
        totalTrades: trades.length,
        totalProfit: totalProfit,
        winRate: trades.length > 0 ? (winTrades / trades.length) * 100 : 0,
        maxDrawdown: 10, // simplified
        profitFactor: winTrades > 0 ? 2.0 : 1.0,
        startDate: candles[0].time,
        endDate: candles[candles.length - 1].time,
        initialBalance: 10000,
      });

      setIsRunning(false);
    } catch (error) {
      console.error('Backtest error:', error);
      setIsRunning(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 text-white p-4">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-4xl font-bold">Backtesting Engine</h1>
        <button
          onClick={() => onNavigate('trading')}
          className="bg-blue-600 hover:bg-blue-700 px-6 py-3 rounded-lg transition"
        >
          Back to Trading
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <div className="bg-slate-700 p-6 rounded-lg border border-slate-600">
            <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
              <BarChart3 size={24} />
              Upload & Run Backtest
            </h2>

            <div className="space-y-4">
              <div>
                <label className="text-sm text-slate-400 block mb-2">CSV File</label>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".csv"
                  onChange={handleFileUpload}
                  className="w-full bg-slate-600 border border-slate-500 rounded px-3 py-2 text-white text-sm"
                />
                {file && (
                  <p className="text-sm text-green-400 mt-2">
                    File selected: {file.name}
                  </p>
                )}
              </div>

              <div>
                <label className="text-sm text-slate-400 block mb-2">Playback Speed</label>
                <div className="flex items-center gap-4">
                  <input
                    type="range"
                    min="0.1"
                    max="5"
                    step="0.1"
                    value={speed}
                    onChange={(e) => setSpeed(parseFloat(e.target.value))}
                    className="flex-1"
                  />
                  <span className="text-white font-bold w-12">{speed.toFixed(1)}x</span>
                </div>
              </div>

              <div className="flex gap-4">
                <button
                  onClick={runBacktest}
                  disabled={!file || isRunning}
                  className="flex-1 flex items-center justify-center gap-2 bg-green-600 hover:bg-green-700 disabled:bg-slate-500 px-4 py-3 rounded-lg transition font-medium"
                >
                  {isRunning ? (
                    <>
                      <Pause size={20} />
                      Running...
                    </>
                  ) : (
                    <>
                      <Play size={20} />
                      Start Backtest
                    </>
                  )}
                </button>
              </div>

              {isRunning && (
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm text-slate-400">Progress</span>
                    <span className="text-sm text-white font-bold">{progress}%</span>
                  </div>
                  <div className="w-full bg-slate-600 rounded-full h-2">
                    <div
                      className="bg-green-500 h-2 rounded-full transition-all"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                </div>
              )}
            </div>
          </div>

          {result && (
            <div className="bg-slate-700 p-6 rounded-lg border border-slate-600 mt-6">
              <h3 className="text-xl font-bold mb-4">Backtest Results</h3>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-slate-600 p-3 rounded">
                  <div className="text-slate-400 text-sm">Total Trades</div>
                  <div className="text-2xl font-bold text-white">{result.totalTrades}</div>
                </div>
                <div className="bg-slate-600 p-3 rounded">
                  <div className="text-slate-400 text-sm">Win Rate</div>
                  <div className={`text-2xl font-bold ${result.winRate > 50 ? 'text-green-400' : 'text-red-400'}`}>
                    {result.winRate.toFixed(1)}%
                  </div>
                </div>
                <div className="bg-slate-600 p-3 rounded">
                  <div className="text-slate-400 text-sm">Total Profit</div>
                  <div className={`text-2xl font-bold ${result.totalProfit >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                    ${result.totalProfit.toFixed(2)}
                  </div>
                </div>
                <div className="bg-slate-600 p-3 rounded">
                  <div className="text-slate-400 text-sm">Profit Factor</div>
                  <div className="text-2xl font-bold text-blue-400">{result.profitFactor.toFixed(2)}</div>
                </div>
              </div>
            </div>
          )}
        </div>

        <div>
          <ChartComponent timeframe={5} symbol="BACKTEST" />
        </div>
      </div>
    </div>
  );
}
