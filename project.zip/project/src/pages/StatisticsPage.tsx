import React, { useEffect, useState } from 'react';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { BarChart3, TrendingUp, TrendingDown, Target } from 'lucide-react';
import tradeManager from '../services/tradeManager';
import { Trade, Rule } from '../types';

interface StatisticsPageProps {
  onNavigate: (page: string) => void;
}

export default function StatisticsPage({ onNavigate }: StatisticsPageProps) {
  const [trades, setTrades] = useState<Trade[]>([]);
  const [rules, setRules] = useState<Rule[]>([]);
  const [stats, setStats] = useState({
    totalTrades: 0,
    winTrades: 0,
    lossTrades: 0,
    winRate: 0,
    totalProfit: 0,
    avgWin: 0,
    avgLoss: 0,
    profitFactor: 1,
  });

  useEffect(() => {
    tradeManager.loadFromStorage();
    const allTrades = tradeManager.getTrades();
    const closedTrades = allTrades.filter(t => t.status === 'closed');
    const allRules = tradeManager.getRules();

    setTrades(allTrades);
    setRules(allRules);

    // حساب الإحصائيات
    const winTrades = closedTrades.filter(t => t.profitLoss! > 0).length;
    const lossTrades = closedTrades.filter(t => t.profitLoss! < 0).length;
    const totalProfit = closedTrades.reduce((sum, t) => sum + (t.profitLoss || 0), 0);
    const avgWin = winTrades > 0
      ? closedTrades.filter(t => t.profitLoss! > 0).reduce((sum, t) => sum + (t.profitLoss || 0), 0) / winTrades
      : 0;
    const avgLoss = lossTrades > 0
      ? Math.abs(closedTrades.filter(t => t.profitLoss! < 0).reduce((sum, t) => sum + (t.profitLoss || 0), 0) / lossTrades)
      : 0;

    setStats({
      totalTrades: closedTrades.length,
      winTrades,
      lossTrades,
      winRate: closedTrades.length > 0 ? (winTrades / closedTrades.length) * 100 : 0,
      totalProfit,
      avgWin,
      avgLoss,
      profitFactor: avgLoss > 0 ? avgWin / avgLoss : 1,
    });
  }, []);

  // بيانات الرسم البياني للصفقات المغلقة
  const chartData = trades
    .filter(t => t.status === 'closed')
    .slice(-30)
    .map((t, index) => ({
      name: `Trade ${index + 1}`,
      profit: t.profitLoss || 0,
      cumulative: trades
        .filter((tr, idx) => idx <= index && tr.status === 'closed')
        .reduce((sum, tr) => sum + (tr.profitLoss || 0), 0),
    }));

  const pieData = [
    { name: 'Wins', value: stats.winTrades, fill: '#22c55e' },
    { name: 'Losses', value: stats.lossTrades, fill: '#ef4444' },
  ];

  const ruleChartData = rules.map(rule => ({
    name: rule.name,
    winRate: rule.winRate,
    trades: rule.totalTrades,
  }));

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 text-white p-4">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-4xl font-bold flex items-center gap-2">
          <BarChart3 size={32} />
          Statistics & Analytics
        </h1>
        <button
          onClick={() => onNavigate('trading')}
          className="bg-blue-600 hover:bg-blue-700 px-6 py-3 rounded-lg transition"
        >
          Back to Trading
        </button>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="bg-slate-700 p-4 rounded-lg border border-slate-600">
          <div className="text-slate-400 text-sm mb-1">Total Trades</div>
          <div className="text-3xl font-bold text-blue-400">{stats.totalTrades}</div>
        </div>
        <div className="bg-slate-700 p-4 rounded-lg border border-slate-600">
          <div className="text-slate-400 text-sm mb-1">Win Rate</div>
          <div className={`text-3xl font-bold ${stats.winRate > 50 ? 'text-green-400' : 'text-red-400'}`}>
            {stats.winRate.toFixed(1)}%
          </div>
        </div>
        <div className="bg-slate-700 p-4 rounded-lg border border-slate-600">
          <div className="text-slate-400 text-sm mb-1">Total Profit</div>
          <div className={`text-3xl font-bold ${stats.totalProfit >= 0 ? 'text-green-400' : 'text-red-400'}`}>
            ${stats.totalProfit.toFixed(2)}
          </div>
        </div>
        <div className="bg-slate-700 p-4 rounded-lg border border-slate-600">
          <div className="text-slate-400 text-sm mb-1">Profit Factor</div>
          <div className="text-3xl font-bold text-amber-400">{stats.profitFactor.toFixed(2)}</div>
        </div>
      </div>

      {/* Detailed Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-slate-700 p-4 rounded-lg border border-slate-600">
          <div className="flex items-center gap-2 mb-3">
            <TrendingUp size={20} className="text-green-400" />
            <span className="text-slate-400">Wins</span>
          </div>
          <div className="text-2xl font-bold text-green-400">{stats.winTrades}</div>
          <div className="text-sm text-slate-400 mt-1">Avg: ${stats.avgWin.toFixed(2)}</div>
        </div>
        <div className="bg-slate-700 p-4 rounded-lg border border-slate-600">
          <div className="flex items-center gap-2 mb-3">
            <TrendingDown size={20} className="text-red-400" />
            <span className="text-slate-400">Losses</span>
          </div>
          <div className="text-2xl font-bold text-red-400">{stats.lossTrades}</div>
          <div className="text-sm text-slate-400 mt-1">Avg: ${stats.avgLoss.toFixed(2)}</div>
        </div>
        <div className="bg-slate-700 p-4 rounded-lg border border-slate-600">
          <div className="flex items-center gap-2 mb-3">
            <Target size={20} className="text-amber-400" />
            <span className="text-slate-400">Risk:Reward</span>
          </div>
          <div className="text-2xl font-bold text-amber-400">1:{stats.profitFactor.toFixed(2)}</div>
          <div className="text-sm text-slate-400 mt-1">Ratio</div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Profit/Loss by Trade */}
        <div className="bg-slate-700 p-4 rounded-lg border border-slate-600">
          <h3 className="text-lg font-bold mb-4">Trade Profitability</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#475569" />
              <XAxis dataKey="name" tick={{ fill: '#cbd5e1', fontSize: 12 }} />
              <YAxis tick={{ fill: '#cbd5e1', fontSize: 12 }} />
              <Tooltip
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569', color: '#fff' }}
              />
              <Bar dataKey="profit" fill="#22c55e" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Win/Loss Distribution */}
        <div className="bg-slate-700 p-4 rounded-lg border border-slate-600 flex flex-col items-center">
          <h3 className="text-lg font-bold mb-4">Win/Loss Distribution</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={pieData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={100}
                paddingAngle={5}
                dataKey="value"
              >
                {pieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.fill} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569', color: '#fff' }}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Rules Performance */}
      {rules.length > 0 && (
        <div className="bg-slate-700 p-4 rounded-lg border border-slate-600">
          <h3 className="text-lg font-bold mb-4">Rules Performance</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-600">
                  <th className="text-left py-3 px-4 text-slate-400">Rule Name</th>
                  <th className="text-center py-3 px-4 text-slate-400">Trades</th>
                  <th className="text-center py-3 px-4 text-slate-400">Win Rate</th>
                  <th className="text-center py-3 px-4 text-slate-400">Total Profit</th>
                  <th className="text-center py-3 px-4 text-slate-400">Avg Profit</th>
                </tr>
              </thead>
              <tbody>
                {rules.map(rule => (
                  <tr key={rule.id} className="border-b border-slate-600 hover:bg-slate-600 transition">
                    <td className="py-3 px-4 text-white font-medium">{rule.name}</td>
                    <td className="text-center py-3 px-4 text-slate-300">{rule.totalTrades}</td>
                    <td className="text-center py-3 px-4">
                      <span className={rule.winRate > 50 ? 'text-green-400' : 'text-red-400'}>
                        {rule.winRate.toFixed(1)}%
                      </span>
                    </td>
                    <td className="text-center py-3 px-4">
                      <span className={rule.totalProfit >= 0 ? 'text-green-400' : 'text-red-400'}>
                        ${rule.totalProfit.toFixed(2)}
                      </span>
                    </td>
                    <td className="text-center py-3 px-4 text-slate-300">
                      ${(rule.totalProfit / rule.totalTrades).toFixed(2)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
