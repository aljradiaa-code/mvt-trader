import React, { useState, useEffect } from 'react';
import { Settings as SettingsIcon, Save, Download, Upload, Trash2, Github } from 'lucide-react';
import { AppSettings, ApiConfig } from '../types';

interface SettingsPageProps {
  onNavigate: (page: string) => void;
}

export default function SettingsPage({ onNavigate }: SettingsPageProps) {
  const [settings, setSettings] = useState<AppSettings>({
    balance: 10000,
    riskPercent: 2,
    timeframes: [5, 15, 60, 240],
    apis: [
      { provider: 'twelvedata', apiKey: '', enabled: true },
      { provider: 'binance', apiKey: '', enabled: false },
    ],
    modelUrl: '',
    githubToken: '',
  });

  const [message, setMessage] = useState('');

  useEffect(() => {
    const saved = localStorage.getItem('app_settings');
    if (saved) {
      setSettings(JSON.parse(saved));
    }
  }, []);

  const handleSave = () => {
    localStorage.setItem('app_settings', JSON.stringify(settings));
    setMessage('Settings saved successfully!');
    setTimeout(() => setMessage(''), 3000);
  };

  const handleExport = () => {
    const data = JSON.stringify(settings, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'trading-settings.json';
    a.click();
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const imported = JSON.parse(event.target?.result as string);
          setSettings(imported);
          setMessage('Settings imported successfully!');
          setTimeout(() => setMessage(''), 3000);
        } catch (error) {
          setMessage('Failed to import settings');
        }
      };
      reader.readAsText(file);
    }
  };

  const handleClear = () => {
    if (confirm('Are you sure? This will clear all trades and rules.')) {
      localStorage.clear();
      setMessage('All data cleared!');
      setTimeout(() => setMessage(''), 3000);
    }
  };

  const updateApi = (index: number, key: string, value: string | boolean) => {
    const newApis = [...settings.apis];
    if (typeof value === 'boolean') {
      newApis[index].enabled = value;
    } else {
      newApis[index].apiKey = value;
    }
    setSettings({ ...settings, apis: newApis });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 text-white p-4">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-4xl font-bold flex items-center gap-2">
          <SettingsIcon size={32} />
          Settings & Configuration
        </h1>
        <button
          onClick={() => onNavigate('trading')}
          className="bg-blue-600 hover:bg-blue-700 px-6 py-3 rounded-lg transition"
        >
          Back to Trading
        </button>
      </div>

      {message && (
        <div className="bg-green-600 text-white p-4 rounded-lg mb-6 flex justify-between items-center">
          <span>{message}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Trading Settings */}
        <div className="bg-slate-700 p-6 rounded-lg border border-slate-600">
          <h2 className="text-xl font-bold mb-4">Trading Parameters</h2>

          <div className="space-y-4">
            <div>
              <label className="text-sm text-slate-400 block mb-2">Initial Balance</label>
              <input
                type="number"
                value={settings.balance}
                onChange={(e) => setSettings({ ...settings, balance: parseFloat(e.target.value) })}
                className="w-full bg-slate-600 border border-slate-500 rounded px-3 py-2 text-white"
              />
            </div>

            <div>
              <label className="text-sm text-slate-400 block mb-2">Risk per Trade (%)</label>
              <input
                type="number"
                step="0.1"
                value={settings.riskPercent}
                onChange={(e) => setSettings({ ...settings, riskPercent: parseFloat(e.target.value) })}
                className="w-full bg-slate-600 border border-slate-500 rounded px-3 py-2 text-white"
              />
            </div>

            <div>
              <label className="text-sm text-slate-400 block mb-2">Active Timeframes</label>
              <div className="space-y-2">
                {[5, 15, 60, 240].map(tf => (
                  <label key={tf} className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.timeframes.includes(tf)}
                      onChange={(e) => {
                        const newTf = e.target.checked
                          ? [...settings.timeframes, tf]
                          : settings.timeframes.filter(t => t !== tf);
                        setSettings({ ...settings, timeframes: newTf });
                      }}
                      className="w-4 h-4"
                    />
                    <span className="text-white">{tf === 5 ? '5M' : tf === 15 ? '15M' : tf === 60 ? '1H' : '4H'}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* API Configuration */}
        <div className="bg-slate-700 p-6 rounded-lg border border-slate-600">
          <h2 className="text-xl font-bold mb-4">API Keys</h2>

          <div className="space-y-4">
            {settings.apis.map((api, index) => (
              <div key={api.provider} className="bg-slate-600 p-4 rounded border border-slate-500">
                <div className="flex items-center justify-between mb-3">
                  <span className="font-medium capitalize">{api.provider}</span>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={api.enabled}
                      onChange={(e) => updateApi(index, 'enabled', e.target.checked)}
                      className="w-4 h-4"
                    />
                    <span className="text-sm text-slate-400">Enabled</span>
                  </label>
                </div>
                <input
                  type="password"
                  value={api.apiKey}
                  onChange={(e) => updateApi(index, 'apiKey', e.target.value)}
                  placeholder={`Enter ${api.provider} API Key`}
                  className="w-full bg-slate-500 border border-slate-400 rounded px-3 py-2 text-white text-sm"
                />
                <div className="text-xs text-slate-400 mt-2">
                  {api.provider === 'twelvedata' && 'Get from: api.twelvedata.com'}
                  {api.provider === 'binance' && 'Get from: binance.com/api'}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Model & GitHub */}
        <div className="bg-slate-700 p-6 rounded-lg border border-slate-600">
          <h2 className="text-xl font-bold mb-4">Model Configuration</h2>

          <div className="space-y-4">
            <div>
              <label className="text-sm text-slate-400 block mb-2">Model URL (TFJS Format)</label>
              <input
                type="text"
                value={settings.modelUrl}
                onChange={(e) => setSettings({ ...settings, modelUrl: e.target.value })}
                placeholder="https://raw.githubusercontent.com/.../model.json"
                className="w-full bg-slate-600 border border-slate-500 rounded px-3 py-2 text-white text-sm"
              />
              <div className="text-xs text-slate-400 mt-2">
                Link to your trained TensorFlow.js model JSON file
              </div>
            </div>

            <div>
              <label className="text-sm text-slate-400 block mb-2">GitHub Token</label>
              <input
                type="password"
                value={settings.githubToken}
                onChange={(e) => setSettings({ ...settings, githubToken: e.target.value })}
                placeholder="ghp_xxxxxxxxxxxxx"
                className="w-full bg-slate-600 border border-slate-500 rounded px-3 py-2 text-white text-sm"
              />
              <div className="text-xs text-slate-400 mt-2">
                For auto-syncing trades and model updates
              </div>
            </div>
          </div>
        </div>

        {/* Data Management */}
        <div className="bg-slate-700 p-6 rounded-lg border border-slate-600">
          <h2 className="text-xl font-bold mb-4">Data Management</h2>

          <div className="space-y-3">
            <button
              onClick={handleSave}
              className="w-full flex items-center justify-center gap-2 bg-green-600 hover:bg-green-700 px-4 py-2 rounded transition"
            >
              <Save size={18} />
              Save Settings
            </button>

            <button
              onClick={handleExport}
              className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded transition"
            >
              <Download size={18} />
              Export Settings
            </button>

            <label className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded transition cursor-pointer">
              <Upload size={18} />
              Import Settings
              <input
                type="file"
                accept=".json"
                onChange={handleImport}
                className="hidden"
              />
            </label>

            <button
              onClick={handleClear}
              className="w-full flex items-center justify-center gap-2 bg-red-600 hover:bg-red-700 px-4 py-2 rounded transition"
            >
              <Trash2 size={18} />
              Clear All Data
            </button>
          </div>
        </div>
      </div>

      {/* GitHub Sync Info */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 p-6 rounded-lg border border-blue-500 mt-6">
        <h2 className="text-xl font-bold mb-2 flex items-center gap-2">
          <Github size={24} />
          GitHub Integration
        </h2>
        <p className="text-blue-100 text-sm mb-4">
          Connect your GitHub account to automatically sync trade results and download updated models.
          Your trade logs will be uploaded to your private repository on each sync.
        </p>
        <div className="text-xs text-blue-200 space-y-1">
          <p>• Trades are logged to logs.json automatically</p>
          <p>• Updated model files are downloaded from releases</p>
          <p>• All data remains private in your repository</p>
        </div>
      </div>
    </div>
  );
}
