import React, { useState } from 'react';
import { Github, Upload, Download, Loader, CheckCircle, AlertCircle } from 'lucide-react';
import tradeManager from '../services/tradeManager';

interface GithubSyncPageProps {
  onNavigate: (page: string) => void;
}

export default function GithubSyncPage({ onNavigate }: GithubSyncPageProps) {
  const [repoUrl, setRepoUrl] = useState(localStorage.getItem('github_repo') || '');
  const [token, setToken] = useState(localStorage.getItem('github_token') || '');
  const [isUploading, setIsUploading] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [status, setStatus] = useState<{ type: 'success' | 'error' | 'info', message: string } | null>(null);

  const handleUploadTrades = async () => {
    if (!token || !repoUrl) {
      setStatus({ type: 'error', message: 'Please provide GitHub token and repository URL' });
      return;
    }

    try {
      setIsUploading(true);
      tradeManager.loadFromStorage();
      const trades = tradeManager.getTrades();
      const trades_data = {
        timestamp: new Date().toISOString(),
        trades: trades,
        summary: {
          total: trades.length,
          closed: trades.filter(t => t.status === 'closed').length,
          open: trades.filter(t => t.status === 'open').length,
        },
      };

      // استخراج معلومات المستودع من الـ URL
      const match = repoUrl.match(/github\.com\/([^/]+)\/([^/]+)/);
      if (!match) {
        setStatus({ type: 'error', message: 'Invalid GitHub repository URL' });
        setIsUploading(false);
        return;
      }

      const [, owner, repo] = match;
      const filename = `logs/${new Date().toISOString().split('T')[0]}_trades.json`;

      // رفع الملف إلى GitHub
      const response = await fetch(
        `https://api.github.com/repos/${owner}/${repo}/contents/${filename}`,
        {
          method: 'PUT',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
            'Accept': 'application/vnd.github.v3+json',
          },
          body: JSON.stringify({
            message: `Trade log update - ${new Date().toISOString()}`,
            content: btoa(JSON.stringify(trades_data, null, 2)),
          }),
        }
      );

      if (response.ok) {
        setStatus({
          type: 'success',
          message: `✅ Successfully uploaded ${trades.length} trades to GitHub!`,
        });
      } else {
        const error = await response.json();
        setStatus({ type: 'error', message: `GitHub Error: ${error.message}` });
      }
    } catch (error) {
      setStatus({ type: 'error', message: `Upload failed: ${error}` });
    } finally {
      setIsUploading(false);
    }
  };

  const handleDownloadModel = async () => {
    if (!token || !repoUrl) {
      setStatus({ type: 'error', message: 'Please provide GitHub token and repository URL' });
      return;
    }

    try {
      setIsDownloading(true);

      // استخراج معلومات المستودع
      const match = repoUrl.match(/github\.com\/([^/]+)\/([^/]+)/);
      if (!match) {
        setStatus({ type: 'error', message: 'Invalid GitHub repository URL' });
        setIsDownloading(false);
        return;
      }

      const [, owner, repo] = match;

      // جلب أحدث إصدار
      const releasesResponse = await fetch(
        `https://api.github.com/repos/${owner}/${repo}/releases/latest`,
        {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Accept': 'application/vnd.github.v3+json',
          },
        }
      );

      if (!releasesResponse.ok) {
        setStatus({ type: 'info', message: 'No model releases found in repository' });
        setIsDownloading(false);
        return;
      }

      const release = await releasesResponse.json();
      const modelAsset = release.assets?.find((a: any) => a.name.includes('model'));

      if (!modelAsset) {
        setStatus({ type: 'info', message: 'No model files found in latest release' });
        setIsDownloading(false);
        return;
      }

      // تحميل ملف النموذج
      const modelResponse = await fetch(modelAsset.browser_download_url);
      const modelData = await modelResponse.blob();

      // حفظ النموذج محلياً
      localStorage.setItem('model_url', modelAsset.browser_download_url);

      setStatus({
        type: 'success',
        message: `✅ Model downloaded successfully! (${(modelData.size / 1024 / 1024).toFixed(2)} MB)`,
      });
    } catch (error) {
      setStatus({ type: 'error', message: `Download failed: ${error}` });
    } finally {
      setIsDownloading(false);
    }
  };

  const saveCredentials = () => {
    localStorage.setItem('github_repo', repoUrl);
    localStorage.setItem('github_token', token);
    setStatus({ type: 'success', message: 'Credentials saved locally' });
    setTimeout(() => setStatus(null), 3000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 text-white p-4">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-4xl font-bold flex items-center gap-2">
          <Github size={32} />
          GitHub Synchronization
        </h1>
        <button
          onClick={() => onNavigate('trading')}
          className="bg-blue-600 hover:bg-blue-700 px-6 py-3 rounded-lg transition"
        >
          Back to Trading
        </button>
      </div>

      {status && (
        <div
          className={`p-4 rounded-lg mb-6 flex items-center gap-3 ${
            status.type === 'success'
              ? 'bg-green-600'
              : status.type === 'error'
              ? 'bg-red-600'
              : 'bg-blue-600'
          }`}
        >
          {status.type === 'success' && <CheckCircle size={20} />}
          {status.type === 'error' && <AlertCircle size={20} />}
          {status.type === 'info' && <AlertCircle size={20} />}
          <span>{status.message}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* GitHub Credentials */}
        <div className="bg-slate-700 p-6 rounded-lg border border-slate-600">
          <h2 className="text-xl font-bold mb-4">GitHub Credentials</h2>

          <div className="space-y-4">
            <div>
              <label className="text-sm text-slate-400 block mb-2">Repository URL</label>
              <input
                type="text"
                value={repoUrl}
                onChange={(e) => setRepoUrl(e.target.value)}
                placeholder="https://github.com/username/repo"
                className="w-full bg-slate-600 border border-slate-500 rounded px-3 py-2 text-white text-sm"
              />
              <div className="text-xs text-slate-400 mt-1">
                Example: https://github.com/myname/trading-logs
              </div>
            </div>

            <div>
              <label className="text-sm text-slate-400 block mb-2">Personal Access Token</label>
              <input
                type="password"
                value={token}
                onChange={(e) => setToken(e.target.value)}
                placeholder="ghp_xxxxxxxxxxxxx"
                className="w-full bg-slate-600 border border-slate-500 rounded px-3 py-2 text-white text-sm"
              />
              <div className="text-xs text-slate-400 mt-1">
                <a
                  href="https://github.com/settings/tokens"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-400 hover:text-blue-300"
                >
                  Create token →
                </a>
              </div>
            </div>

            <button
              onClick={saveCredentials}
              className="w-full bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded transition font-medium"
            >
              Save Credentials
            </button>
          </div>
        </div>

        {/* GitHub Status */}
        <div className="bg-slate-700 p-6 rounded-lg border border-slate-600">
          <h2 className="text-xl font-bold mb-4">Integration Status</h2>

          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-slate-600 rounded">
              <span className="text-slate-300">GitHub Connection</span>
              <span className={token ? 'text-green-400 font-bold' : 'text-red-400 font-bold'}>
                {token ? '✓ Configured' : '✗ Not Set'}
              </span>
            </div>

            <div className="flex items-center justify-between p-3 bg-slate-600 rounded">
              <span className="text-slate-300">Repository</span>
              <span className={repoUrl ? 'text-green-400 font-bold' : 'text-red-400 font-bold'}>
                {repoUrl ? '✓ Set' : '✗ Not Set'}
              </span>
            </div>

            <div className="text-sm text-slate-400 p-3 bg-slate-600 rounded">
              <p className="font-bold mb-2">Required Permissions:</p>
              <ul className="list-disc list-inside space-y-1">
                <li>repo (full control of private repositories)</li>
                <li>workflow (if using GitHub Actions)</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Sync Operations */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
        {/* Upload Trades */}
        <div className="bg-slate-700 p-6 rounded-lg border border-slate-600">
          <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
            <Upload size={22} />
            Upload Trade Logs
          </h2>

          <p className="text-slate-400 text-sm mb-4">
            Upload your closed trades to GitHub as a timestamped JSON file.
            This helps track your trading performance and create a history for model training.
          </p>

          <button
            onClick={handleUploadTrades}
            disabled={isUploading || !token || !repoUrl}
            className="w-full flex items-center justify-center gap-2 bg-green-600 hover:bg-green-700 disabled:bg-slate-500 px-4 py-3 rounded transition font-medium"
          >
            {isUploading ? (
              <>
                <Loader size={20} className="animate-spin" />
                Uploading...
              </>
            ) : (
              <>
                <Upload size={20} />
                Upload Trades
              </>
            )}
          </button>

          <div className="mt-4 text-xs text-slate-400">
            <p className="font-bold mb-2">Uploaded to:</p>
            <code className="bg-slate-600 p-2 rounded block break-all">
              logs/YYYY-MM-DD_trades.json
            </code>
          </div>
        </div>

        {/* Download Model */}
        <div className="bg-slate-700 p-6 rounded-lg border border-slate-600">
          <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
            <Download size={22} />
            Download Model
          </h2>

          <p className="text-slate-400 text-sm mb-4">
            Download the latest trained model from your GitHub releases.
            The app will automatically use the updated model for predictions.
          </p>

          <button
            onClick={handleDownloadModel}
            disabled={isDownloading || !token || !repoUrl}
            className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-500 px-4 py-3 rounded transition font-medium"
          >
            {isDownloading ? (
              <>
                <Loader size={20} className="animate-spin" />
                Downloading...
              </>
            ) : (
              <>
                <Download size={20} />
                Download Model
              </>
            )}
          </button>

          <div className="mt-4 text-xs text-slate-400">
            <p className="font-bold mb-2">Fetches from:</p>
            <code className="bg-slate-600 p-2 rounded block break-all">
              Latest Release Assets
            </code>
          </div>
        </div>
      </div>

      {/* How It Works */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 p-6 rounded-lg border border-blue-500 mt-6">
        <h2 className="text-xl font-bold mb-4">How It Works</h2>
        <div className="space-y-3 text-sm text-blue-100">
          <div className="flex gap-3">
            <div className="flex-shrink-0 w-6 h-6 rounded-full bg-blue-400 flex items-center justify-center text-xs font-bold">1</div>
            <p>Connect your GitHub personal repository with a write access token</p>
          </div>
          <div className="flex gap-3">
            <div className="flex-shrink-0 w-6 h-6 rounded-full bg-blue-400 flex items-center justify-center text-xs font-bold">2</div>
            <p>Trade results are automatically uploaded to logs/ folder</p>
          </div>
          <div className="flex gap-3">
            <div className="flex-shrink-0 w-6 h-6 rounded-full bg-blue-400 flex items-center justify-center text-xs font-bold">3</div>
            <p>Your GitHub Actions (or external service) retrains the model</p>
          </div>
          <div className="flex gap-3">
            <div className="flex-shrink-0 w-6 h-6 rounded-full bg-blue-400 flex items-center justify-center text-xs font-bold">4</div>
            <p>Download the updated model directly in the app</p>
          </div>
        </div>
      </div>
    </div>
  );
}
