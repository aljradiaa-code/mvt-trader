import React, { useEffect, useState, useRef } from 'react';
import { TrendingUp, TrendingDown, Settings, BarChart3, Activity, Download } from 'lucide-react';
import { fetchMultipleTimeframes } from '../services/dataService';
import { analyzeCandles, loadModel } from '../services/tensorflowService';
import candleBuffer from '../services/candleBuffer';
import tradeManager from '../services/tradeManager';
import ChartComponent from '../components/ChartComponent';
import TradePanel from '../components/TradePanel';
import RulesPanel from '../components/RulesPanel';
import { Trade, Candle } from '../types';

interface LiveTradingPageProps {
  onNavigate: (page: string) => void;
}

export default function LiveTradingPage({ onNavigate }: LiveTradingPageProps) {
  const [apiKey, setApiKey] = useState(localStorage.getItem('twelvedata_api') || '');
  const [symbol, setSymbol] = useState('EURUSD');
  const [selectedTimeframe, setSelectedTimeframe] = useState(5);
  const [isLoading, setIsLoading] = useState(false);
  const [trades, setTrades] = useState<Trade[]>([]);
  const [stats, setStats] = useState({ balance: 10000, openTrades: 0, totalProfit: 0 });
  const [lastPrice, setLastPrice] = useState(0);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    tradeManager.loadFromStorage();
    setTrades(tradeManager.getTrades());
    updateStats();
  }, []);

  useEffect(() => {
    if (apiKey) {
      localStorage.setItem('twelvedata_api', apiKey);
      startLiveUpdate();
      return () => stopLiveUpdate();
    }
  }, [apiKey, symbol]);

  const updateStats = () => {
    const openTrades = tradeManager.getOpenTrades();
    const closedTrades = tradeManager.getClosedTrades();
    const totalProfit = closedTrades.reduce((sum, t) => sum + (t.profitLoss || 0), 0);

    setStats({
      balance: 10000 + totalProfit,
      openTrades: openTrades.length,
      totalProfit: totalProfit,
    });
  };

  const startLiveUpdate = () => {
    if (intervalRef.current) clearInterval(intervalRef.current);

    intervalRef.current = setInterval(async () => {
      if (!apiKey) return;

      try {
        setIsLoading(true);
        const data = await fetchMultipleTimeframes(apiKey, symbol, [5, 15, 60, 240]);

        // تحديث المخزن المؤقت
        Object.entries(data).forEach(([tf, candles]) => {
          const timeframe = parseInt(tf);
          candles.forEach(candle => {
            candleBuffer.addCandle(timeframe, {
              time: candle.time,
              open: candle.o,
              high: candle.h,
              low: candle.l,
              close: candle.c,
              volume: candle.v,
            });
          });
        });

        // تحليل آخر 50 شمعة
        const selectedCandles = candleBuffer.getCandles(selectedTimeframe);
        if (selectedCandles.length > 0) {
          setLastPrice(selectedCandles[selectedCandles.length - 1].close);

          const candles5M = candleBuffer.getCandles(5);
          const candles15M = candleBuffer.getCandles(15);
          const candles1H = candleBuffer.getCandles(60);
          const candles4H = candleBuffer.getCandles(240);

          if (candles5M.length >= 10) {
            const analysis = await analyzeCandles(
              candles5M.map(c => ({ o: c.open, h: c.high, l: c.low, c: c.close, v: c.volume }))
            );

            // إذا كان هناك إشارة شراء أو بيع، أضف صفقة جديدة
            if (analysis.signal !== 'hold' && analysis.confidence > 0.7) {
              const latestCandle = candles5M[candles5M.length - 1];
              const newTrade = tradeManager.addTrade({
                entryPrice: latestCandle.close,
                quantity: 1,
                entryTime: latestCandle.time,
                rule: `Rule_${analysis.signal.toUpperCase()}_AUTO`,
                status: 'open',
                stopLoss: analysis.signal === 'buy'
                  ? latestCandle.close - (latestCandle.high - latestCandle.low)
                  : latestCandle.close + (latestCandle.high - latestCandle.low),
                takeProfit: analysis.signal === 'buy'
                  ? latestCandle.close + (latestCandle.high - latestCandle.low) * 2
                  : latestCandle.close - (latestCandle.high - latestCandle.low) * 2,
                exitPrice: null,
                exitTime: null,
                profitLoss: null,
                profitLossPercent: null,
              });

              setTrades([...trades, newTrade]);
            }
          }
        }

        updateStats();
        setIsLoading(false);
      } catch (error) {
        console.error('Live update error:', error);
        setIsLoading(false);
      }
    }, 5000);
  };

  const stopLiveUpdate = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  };

  const closeTrade = (tradeId: string) => {
    if (lastPrice > 0) {
      tradeManager.closeTrade(tradeId, lastPrice, Date.now() / 1000);
      setTrades(tradeManager.getTrades());
      updateStats();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 text-white p-4">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-4xl font-bold mb-2">Trading Terminal</h1>
          <p className="text-slate-400">Real-time Multi-Timeframe Analysis</p>
        </div>
        <button
          onClick={() => onNavigate('settings')}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 px-6 py-3 rounded-lg transition"
        >
          <Settings size={20} />
          Settings
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-slate-700 p-4 rounded-lg border border-slate-600">
          <div className="text-slate-400 text-sm mb-1">Account Balance</div>
          <div className="text-3xl font-bold text-green-400">${stats.balance.toFixed(2)}</div>
          <div className="text-xs text-slate-500 mt-2">+${stats.totalProfit.toFixed(2)}</div>
        </div>
        <div className="bg-slate-700 p-4 rounded-lg border border-slate-600">
          <div className="text-slate-400 text-sm mb-1">Open Trades</div>
          <div className="text-3xl font-bold text-blue-400">{stats.openTrades}</div>
        </div>
        <div className="bg-slate-700 p-4 rounded-lg border border-slate-600">
          <div className="text-slate-400 text-sm mb-1">Last Price</div>
          <div className="text-3xl font-bold text-amber-400">{lastPrice.toFixed(5)}</div>
        </div>
      </div>

      {/* Controls */}
      <div className="bg-slate-700 p-4 rounded-lg border border-slate-600 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="text-sm text-slate-400 block mb-2">API Key</label>
            <input
              type="password"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder="Enter TwelveData API Key"
              className="w-full bg-slate-600 border border-slate-500 rounded px-3 py-2 text-white text-sm"
            />
          </div>
          <div>
            <label className="text-sm text-slate-400 block mb-2">Symbol</label>
            <input
              type="text"
              value={symbol}
              onChange={(e) => setSymbol(e.target.value.toUpperCase())}
              placeholder="EURUSD"
              className="w-full bg-slate-600 border border-slate-500 rounded px-3 py-2 text-white text-sm"
            />
          </div>
          <div>
            <label className="text-sm text-slate-400 block mb-2">Timeframe</label>
            <select
              value={selectedTimeframe}
              onChange={(e) => setSelectedTimeframe(parseInt(e.target.value))}
              className="w-full bg-slate-600 border border-slate-500 rounded px-3 py-2 text-white text-sm"
            >
              <option value={5}>5M</option>
              <option value={15}>15M</option>
              <option value={60}>1H</option>
              <option value={240}>4H</option>
            </select>
          </div>
          <div className="flex items-end">
            <button
              onClick={startLiveUpdate}
              disabled={isLoading || !apiKey}
              className="w-full bg-green-600 hover:bg-green-700 disabled:bg-slate-500 px-4 py-2 rounded transition font-medium text-sm"
            >
              {isLoading ? 'Loading...' : 'Start'}
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <ChartComponent
            timeframe={selectedTimeframe}
            symbol={symbol}
          />
        </div>
        <div>
          <TradePanel
            trades={trades}
            onCloseTrade={closeTrade}
          />
        </div>
      </div>

      {/* Rules Panel */}
      <RulesPanel rules={tradeManager.getRules()} />
    </div>
  );
}
