#!/bin/bash

# MVT-VRL Trader - Build & Deploy Script
# نسخة شاملة لبناء وتوزيع التطبيق

set -e

# ألوان للطباعة
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# الدوال المساعدة
print_header() {
    echo -e "${BLUE}════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}════════════════════════════════════════════════${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_info() {
    echo -e "${YELLOW}ℹ️ $1${NC}"
}

# التحقق من المتطلبات
check_requirements() {
    print_header "جاري التحقق من المتطلبات"

    if ! command -v node &> /dev/null; then
        print_error "Node.js غير مثبت"
        exit 1
    fi
    print_success "Node.js مثبت: $(node -v)"

    if ! command -v npm &> /dev/null; then
        print_error "npm غير مثبت"
        exit 1
    fi
    print_success "npm مثبت: $(npm -v)"

    if ! command -v java &> /dev/null; then
        print_error "Java JDK غير مثبت - يرجى تثبيت JDK 11+"
        exit 1
    fi
    print_success "Java JDK مثبت: $(java -version 2>&1 | head -1)"

    if [ -z "$ANDROID_SDK_ROOT" ] && [ -z "$ANDROID_HOME" ]; then
        print_error "Android SDK لم يتم تكوينه - set ANDROID_SDK_ROOT أو ANDROID_HOME"
        exit 1
    fi
    print_success "Android SDK مثبت"
}

# بناء النسخة الويب
build_web() {
    print_header "بناء النسخة الويب"

    print_info "تثبيت الحزم..."
    npm install

    print_info "بناء النسخة الإنتاجية..."
    npm run build

    if [ -d "dist" ]; then
        print_success "تم بناء النسخة الويب بنجاح"
        ls -lh dist/ | head -10
    else
        print_error "فشل بناء النسخة الويب"
        exit 1
    fi
}

# تحديث Capacitor
update_capacitor() {
    print_header "تحديث Capacitor"

    print_info "مزامنة الملفات مع Android..."
    npx cap sync

    print_success "تم تحديث Capacitor"
}

# بناء APK (Debug)
build_apk_debug() {
    print_header "بناء APK Debug"

    print_info "بناء في المجلد android..."
    cd android

    print_info "تنظيف المشاريع السابقة..."
    ./gradlew clean

    print_info "بناء APK Debug..."
    ./gradlew assembleDebug

    cd ..

    if [ -f "android/app/build/outputs/apk/debug/app-debug.apk" ]; then
        APK_SIZE=$(ls -lh android/app/build/outputs/apk/debug/app-debug.apk | awk '{print $5}')
        print_success "تم بناء APK Debug بنجاح - الحجم: $APK_SIZE"
        print_info "الملف: android/app/build/outputs/apk/debug/app-debug.apk"
    else
        print_error "فشل بناء APK Debug"
        exit 1
    fi
}

# بناء APK (Release)
build_apk_release() {
    print_header "بناء APK Release"

    print_info "للـ Release، تحتاج إلى signing configuration"
    print_info "اتبع الخطوات في: android/app/build.gradle"

    cd android

    print_info "بناء APK Release..."
    ./gradlew assembleRelease

    cd ..

    if [ -f "android/app/build/outputs/apk/release/app-release.apk" ]; then
        APK_SIZE=$(ls -lh android/app/build/outputs/apk/release/app-release.apk | awk '{print $5}')
        print_success "تم بناء APK Release بنجاح - الحجم: $APK_SIZE"
        print_info "الملف: android/app/build/outputs/apk/release/app-release.apk"
    else
        print_error "فشل بناء APK Release"
    fi
}

# تثبيت APK على الهاتف
install_apk() {
    print_header "تثبيت APK على الهاتف"

    if ! command -v adb &> /dev/null; then
        print_error "adb غير مثبت - يرجى تثبيت Android SDK Platform Tools"
        exit 1
    fi

    print_info "جاري البحث عن الأجهزة المتصلة..."
    DEVICES=$(adb devices -l | grep -v "^List" | grep -v "^$" | wc -l)

    if [ "$DEVICES" -eq 0 ]; then
        print_error "لا توجد أجهزة متصلة"
        print_info "تأكد من:"
        print_info "1. توصيل الهاتف بالحاسوب"
        print_info "2. تفعيل USB Debugging"
        exit 1
    fi

    print_info "عدد الأجهزة: $DEVICES"

    print_info "جاري التثبيت..."
    adb install -r android/app/build/outputs/apk/debug/app-debug.apk

    print_success "تم التثبيت بنجاح"
    print_info "افتح التطبيق من قائمة التطبيقات: MVT-VRL Trader"
}

# عرض السجلات
show_logs() {
    print_header "عرض سجلات التطبيق"

    if ! command -v adb &> /dev/null; then
        print_error "adb غير مثبت"
        exit 1
    fi

    print_info "عرض السجلات الحية (Ctrl+C للإيقاف)..."
    adb logcat | grep -i mvtrader
}

# تنظيف المشاريع
clean() {
    print_header "تنظيف المشاريع"

    print_info "حذف dist/"
    rm -rf dist

    print_info "حذف node_modules/.cache"
    rm -rf node_modules/.cache

    print_info "تنظيف Gradle..."
    cd android
    ./gradlew clean
    cd ..

    print_success "تم التنظيف"
}

# الخيارات الرئيسية
case "${1:-help}" in
    web)
        build_web
        ;;
    sync)
        update_capacitor
        ;;
    debug)
        build_web
        update_capacitor
        build_apk_debug
        ;;
    release)
        build_web
        update_capacitor
        build_apk_release
        ;;
    install)
        install_apk
        ;;
    logs)
        show_logs
        ;;
    clean)
        clean
        ;;
    full)
        check_requirements
        build_web
        update_capacitor
        build_apk_debug
        install_apk
        ;;
    *)
        echo -e "${BLUE}"
        echo "════════════════════════════════════════════════════════════════"
        echo "MVT-VRL Trader - Build & Deploy"
        echo "════════════════════════════════════════════════════════════════"
        echo ""
        echo -e "${NC}الأوامر المتاحة:${BLUE}"
        echo ""
        echo "  web           - بناء النسخة الويب فقط"
        echo "  sync          - مزامنة Capacitor مع Android"
        echo "  debug         - بناء APK Debug كامل (Web + Sync + APK)"
        echo "  release       - بناء APK Release"
        echo "  install       - تثبيت APK على الهاتف"
        echo "  logs          - عرض السجلات الحية"
        echo "  clean         - تنظيف المشاريع"
        echo "  full          - البناء والتثبيت الكامل"
        echo ""
        echo -e "${YELLOW}أمثلة الاستخدام:${NC}"
        echo "  ./build-and-deploy.sh debug         # بناء APK Debug والتثبيت"
        echo "  ./build-and-deploy.sh release       # بناء APK Release"
        echo "  ./build-and-deploy.sh full          # البناء الكامل"
        echo "  ./build-and-deploy.sh install       # التثبيت فقط"
        echo ""
        echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
        exit 0
        ;;
esac
