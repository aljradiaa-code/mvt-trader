#!/bin/bash

echo "========================================="
echo "MVT-VRL Trader - APK Builder"
echo "========================================="
echo ""

# التحقق من وجود Android SDK
if [ -z "$ANDROID_SDK_ROOT" ]; then
    echo "⚠️  تحذير: ANDROID_SDK_ROOT لم تكن محددة"
    echo "   يرجى تثبيت Android SDK أولاً"
    echo ""
fi

echo "1️⃣  بناء النسخة الإنتاجية..."
npm run build

if [ $? -ne 0 ]; then
    echo "❌ فشل البناء!"
    exit 1
fi

echo ""
echo "2️⃣  تثبيت Capacitor..."
npm install @capacitor/core @capacitor/cli @capacitor/android @capacitor/ios

echo ""
echo "3️⃣  إنشاء تطبيق Capacitor..."
if [ ! -d "android" ]; then
    npx cap init --web-dir=dist
fi

echo ""
echo "4️⃣  إضافة منصة Android..."
npx cap add android 2>/dev/null || echo "Android موجود بالفعل"

echo ""
echo "5️⃣  نسخ الملفات..."
npx cap sync

echo ""
echo "6️⃣  بناء APK..."
cd android
./gradlew assembleDebug
cd ..

echo ""
echo "========================================="
echo "✅ اكتمل البناء!"
echo ""
echo "ملف APK الموجود في:"
echo "android/app/build/outputs/apk/debug/app-debug.apk"
echo ""
echo "لتثبيت على الهاتف:"
echo "adb install android/app/build/outputs/apk/debug/app-debug.apk"
echo "========================================="
