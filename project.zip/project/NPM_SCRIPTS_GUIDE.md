# npm Scripts - الأوامر السريعة للتطبيق

## الأوامر الويب (الأصلية)

```bash
npm run dev          # تشغيل التطبيق في وضع التطوير
npm run build        # بناء النسخة الإنتاجية
npm run preview      # عرض النسخة المبنية
npm run lint         # فحص الأخطاء
npm run typecheck    # فحص أنواع TypeScript
```

---

## الأوامر الجديدة (Android)

### الإعداد الأول:

```bash
# تهيئة Capacitor (يُفعل مرة واحدة)
npm run cap:init

# إضافة منصة Android (يُفعل مرة واحدة)
npm run cap:add
```

### البناء والتطوير:

```bash
# بناء النسخة الويب الإنتاجية
npm run android:web

# مزامنة مع Android
npm run android:sync

# بناء APK Debug (الأسهل)
npm run android:debug

# بناء APK Release
npm run android:release

# تنظيف مشروع Android
npm run android:clean

# بناء سريع (= android:debug)
npm run android:build
```

### استخدام السكريبتات:

```bash
# استخدام السكريبت الرئيسي (Linux/Mac)
npm run apk full     # بناء كامل + تثبيت
npm run apk debug    # بناء Debug
npm run apk release  # بناء Release
npm run apk install  # تثبيت فقط
npm run apk clean    # تنظيف
```

---

## سير العمل (Workflow)

### للتطوير والاختبار:

```bash
# 1. أول مرة فقط
npm run cap:init
npm run cap:add

# 2. في كل مرة تطوير
npm run dev          # تطوير الويب
npm run android:web  # بناء الويب
npm run android:sync # مزامنة مع Android
npm run android:build# بناء APK
```

### للنشر:

```bash
# 1. بناء النسخة الإنتاجية
npm run build

# 2. مزامنة مع Android
npm run android:sync

# 3. بناء Release
npm run android:release

# النتيجة: android/app/build/outputs/apk/release/app-release.apk
```

---

## الخيارات المختصرة (على Linux/Mac):

```bash
# بدلاً من السكريبت الطويل
./build-and-deploy.sh full

# يمكنك استخدام:
npm run android:debug && \
adb install -r android/app/build/outputs/apk/debug/app-debug.apk
```

---

## مثال عملي كامل

```bash
# 1. التطوير الأولي
npm install          # تثبيت الحزم
npm run dev          # تشغيل الويب

# 2. بناء لـ Android أول مرة
npm run cap:init     # إعداد Capacitor
npm run cap:add      # إضافة Android

# 3. بناء وتثبيت APK
npm run android:debug# بناء
npm run android:web  # بناء الويب (إن لم تفعل قبلاً)

# 4. التثبيت (يدوي على الهاتف)
adb install -r android/app/build/outputs/apk/debug/app-debug.apk
```

---

## ملاحظات مهمة

### متى تستخدم أي أمر؟

| الحالة | الأمر |
|--------|------|
| تطوير الويب | `npm run dev` |
| بناء الويب | `npm run build` |
| بناء APK Debug | `npm run android:debug` |
| بناء APK Release | `npm run android:release` |
| مزامنة فقط | `npm run android:sync` |
| بناء كامل | `npm run apk full` (أو السكريبت) |

### الفرق بين:
- `npm run android:debug` - يبني APK Debug (أسرع)
- `npm run android:release` - يبني APK Release (أبطأ، للنشر)
- `npm run apk debug` - يستخدم السكريبت (مع رسائل ملونة)

---

## استكشاف الأخطاء:

```bash
# إذا فشل البناء
npm run android:clean  # نظّف أولاً

# ثم جرب مرة أخرى
npm run android:debug
```

---

## الملفات الناتجة:

```bash
# بعد npm run android:debug
android/app/build/outputs/apk/debug/app-debug.apk

# بعد npm run android:release
android/app/build/outputs/apk/release/app-release.apk
```

---

**ملخص**: استخدم `npm run android:*` للتطوير السريع، و `./build-and-deploy.sh full` للبناء الكامل! 🚀
