# 🚀 البدء السريع - MVT-VRL Trader

## ⏱️ في 5 دقائق فقط

### 1️⃣ تثبيت وتشغيل (1 دقيقة)

```bash
# في المجلد الرئيسي
npm install
npm run dev
```

ستفتح الصفحة تلقائياً على: http://localhost:5173

### 2️⃣ إدخال مفتاح API (1 دقيقة)

```
الصفحة الرئيسية → اضغط "Settings"

API Keys → TwelveData:
انسخ وألصق: 6a1f3b95b77841ceb3beb709fb50763e

اضغط "Enable" و "Save Settings"
```

### 3️⃣ ابدأ التداول (2 دقيقة)

```
الصفحة الرئيسية → اضغط "Start Trading"

ستظهر لك:
✓ الرسم البياني
✓ الصفقات المفتوحة
✓ الإحصائيات

اضغط "Start" لبدء التحديث الحي
```

### 4️⃣ اختبر الاستراتيجيات (1 دقيقة)

```
الصفحة الرئيسية → اضغط "Run Backtest"

1. أرفع ملف CSV
2. انقر "Start Backtest"
3. شاهد النتائج
```

---

## 🎯 الصفحات الرئيسية

| الصفحة | الرابط | الميزة |
|--------|--------|--------|
| التداول الحي | Home → Start Trading | بيانات حية + صفقات تلقائية |
| الباك تست | Home → Run Backtest | اختبار على بيانات تاريخية |
| الإحصائيات | Home → Statistics | تحليل الأداء |
| الإعدادات | Home → Settings | API Keys وإدارة البيانات |
| GitHub | Home → GitHub Sync | رفع الصفقات وتحديث النموذج |

---

## ✨ أمثلة استخدام سريعة

### مثال 1: التداول الحي

```
✓ افتح Live Trading
✓ ضع Symbol: EURUSD
✓ اختر Timeframe: 5M
✓ انقر Start

→ ستبدأ الصفقات التلقائية على الفور
```

### مثال 2: الباك تست

```
✓ اذهب إلى Backtesting
✓ أرفع ملف CSV
✓ غيّر السرعة (0.5x - 5x)
✓ انقر Start Backtest

→ شاهد نتائج الاختبار على التاريخ
```

### مثال 3: مزامنة GitHub

```
✓ اذهب إلى GitHub Sync
✓ أدخل GitHub Token
✓ أدخل رابط المستودع
✓ انقر Upload Trades

→ سيتم رفع الصفقات إلى GitHub تلقائياً
```

---

## 🔧 الأوامر السريعة

```bash
# التشغيل
npm run dev

# البناء
npm run build

# التحقق من الأخطاء
npm run lint

# فحص الأنواع
npm run typecheck

# بناء APK
chmod +x build-apk.sh
./build-apk.sh
```

---

## 📱 توليد APK

### الطريقة السهلة:
```bash
chmod +x build-apk.sh
./build-apk.sh
```

### ملف APK:
`android/app/build/outputs/apk/debug/app-debug.apk`

### التثبيت:
```bash
adb install android/app/build/outputs/apk/debug/app-debug.apk
```

---

## 🎮 الاختصارات

| الاختصار | الوظيفة |
|----------|--------|
| 5M | فريم 5 دقائق |
| 15M | فريم 15 دقيقة |
| 1H | فريم ساعة واحدة |
| 4H | فريم 4 ساعات |
| SL | وقف الخسارة (Stop Loss) |
| TP | هدف الربح (Take Profit) |

---

## ❓ أسئلة شائعة

**س: هل يحتاج إنترنت؟**
- ✅ للتداول الحي: نعم
- ✅ للباك تست: لا
- ✅ للإحصائيات: لا

**س: هل البيانات آمنة؟**
- ✅ جميع البيانات محلية في المتصفح
- ✅ لا توجد خوادم مركزية
- ✅ فقط GitHub اختياري للمزامنة

**س: كم السعر؟**
- ✅ مجاني تماماً
- ✅ بدون اشتراكات
- ✅ بدون إعلانات

**س: هل يعمل بدون API Key؟**
- ❌ للتداول الحي: يحتاج API
- ✅ للباك تست: لا يحتاج

---

## 🆘 استكشاف الأخطاء السريع

| المشكلة | الحل |
|--------|------|
| "Cannot find module" | جرب `npm install` |
| "Port already in use" | استخدم `npm run dev -- --port 3000` |
| "API Key invalid" | تحقق من النسخ الصحيح بدون مسافات |
| "Build failed" | جرب `npm run lint` و `npm run typecheck` |

---

## 📚 المزيد من المعلومات

- 📖 `README_AR.md` - دليل شامل
- 📋 `SETUP.md` - خطوات التثبيت المفصلة
- 🗂️ `FILE_STRUCTURE.md` - هيكل الملفات
- 🔗 `GITHUB_SETUP.md` - إعداد GitHub

---

## ✅ ملخص سريع

```
✓ npm install        → تثبيت الحزم
✓ npm run dev        → تشغيل التطبيق
✓ Ctrl+C             → إيقاف التطبيق
✓ Settings           → إدخال API Key
✓ Start Trading      → بدء التداول الحي
✓ Run Backtest       → اختبار الاستراتيجيات
✓ ./build-apk.sh     → بناء APK
```

---

**🎉 هذا كل شيء! استمتع بالتطبيق!**

**آخر تحديث:** June 2024
