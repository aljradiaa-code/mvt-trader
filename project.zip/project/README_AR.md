# MVT-VRL Trader - Multi-Timeframe Vision Reinforcement Learning Trading System

تطبيق تداول ذكي مستقل يجمع بين تحليل الأسواق الآلي والتعلم المعزز لتنفيذ صفقات تداول تلقائية.

## المميزات الرئيسية

✅ **التداول الحي** - تحليل متزامن لـ 4 فريمات (5M, 15M, 1H, 4H)  
✅ **الباك تست** - اختبار الاستراتيجيات على بيانات تاريخية مع تحكم بسرعة الحركة  
✅ **النموذج الذكي** - شبكة عصبية TensorFlow.js تعمل محلياً في المتصفح  
✅ **إدارة الصفقات** - إيقاف خسارة وهدف ربح تلقائي  
✅ **مزامنة GitHub** - رفع نتائج التداول وتحميل نماذج محدثة تلقائياً  
✅ **الإحصائيات** - تحليل شامل لأداء التداول والقوانين  

## المتطلبات

- Node.js 16+
- npm أو yarn
- متصفح حديث يدعم WebGL

## التثبيت والتشغيل

```bash
# تثبيت الحزم
npm install

# تشغيل التطبيق في وضع التطوير
npm run dev

# بناء النسخة الإنتاجية
npm run build
```

## إعدادات TwelveData API

1. إنشء حساب مجاني على [twelvedata.com](https://twelvedata.com)
2. احصل على API Key الخاص بك
3. أضفه في صفحة الإعدادات (Settings)

```
API Key: 6a1f3b95b77841ceb3beb709fb50763e
```

## إعدادات GitHub للمزامنة

### إنشاء Token

1. اذهب إلى [GitHub Settings → Developer Settings](https://github.com/settings/tokens)
2. انقر على "Generate new token (classic)"
3. اختر الصلاحيات:
   - `repo` - الوصول الكامل للمستودعات الخاصة
   - `workflow` - (اختياري)
4. انسخ الـ Token

### إعداد المستودع

```bash
# إنشاء مستودع جديد على GitHub باسم مثلاً: trading-logs

# المجلدات المطلوبة:
logs/           # لحفظ سجلات التداول اليومية
releases/       # للنماذج المحدثة
```

## هيكل البيانات

### سجل الصفقات (logs/YYYY-MM-DD_trades.json)
```json
{
  "timestamp": "2024-06-04T10:30:00Z",
  "trades": [
    {
      "id": "trade_001",
      "entryPrice": 1.0850,
      "exitPrice": 1.0875,
      "quantity": 1.0,
      "profitLoss": 25,
      "rule": "Rule_LONG_5_15_60",
      "status": "closed"
    }
  ],
  "summary": {
    "total": 5,
    "closed": 5,
    "open": 0
  }
}
```

## صيغة ملف CSV للباك تست

```csv
DateTime,Open,High,Low,Close,Volume
2024-01-01 09:00:00,1.0800,1.0850,1.0790,1.0820,5000
2024-01-01 09:05:00,1.0820,1.0860,1.0815,1.0845,4500
```

## الصفحات الرئيسية

### 1. الصفحة الرئيسية (Home)
- عرض عام للميزات
- روابط سريعة لكل صفحة

### 2. التداول الحي (Live Trading)
- بيانات حية من TwelveData
- رسم بياني تفاعلي
- إدارة الصفقات المفتوحة
- تنفيذ صفقات تلقائية

### 3. الباك تست (Backtesting)
- تحميل ملفات CSV
- تشغيل الاختبارات بسرعات مختلفة
- عرض النتائج والإحصائيات

### 4. الإحصائيات (Statistics)
- مقاييس الأداء الشاملة
- أداء كل قاعدة تداول
- رسوم بيانية توضيحية
- معدل الفوز والخسارة

### 5. الإعدادات (Settings)
- إعدادات التداول (الرصيد، نسبة المخاطرة)
- إدارة مفاتيح API
- رابط النموذج الذكي
- تصدير/استيراد الإعدادات

### 6. مزامنة GitHub (GitHub Sync)
- رفع سجلات التداول
- تحميل النماذج المحدثة
- إدارة بيانات اعتماد GitHub

## المتغيرات المهمة

### localStorage Keys
```javascript
'twelvedata_api'      // مفتاح TwelveData API
'trades'             // سجل الصفقات
'rules'              // قواعد التداول المكتشفة
'app_settings'       // إعدادات التطبيق
'github_repo'        // رابط مستودع GitHub
'github_token'       // توكن GitHub
```

## معايير الصفقات التلقائية

```javascript
{
  entryPrice: رقم,      // سعر الدخول
  stopLoss: رقم,        // نقطة إيقاف الخسارة
  takeProfit: رقم,      // هدف الربح
  quantity: رقم,        // الكمية
  rule: نص,             // اسم القاعدة المستخدمة
  status: 'open'|'closed',
  profitLoss: رقم,      // الربح/الخسارة بالنقاط
}
```

## نموذج TensorFlow.js

يجب أن يكون النموذج بصيغة TensorFlow.js:

```javascript
// في ملف settings
modelUrl: "https://raw.githubusercontent.com/username/repo/main/model/model.json"
```

## توليد APK

### باستخدام Capacitor

```bash
# تثبيت Capacitor
npm install @capacitor/core @capacitor/cli @capacitor/android

# إنشاء تطبيق Android
npx cap init --web-dir=dist

# إضافة Android
npx cap add android

# بناء والتشغيل
npx cap build android
```

## الأخطاء الشائعة وحلولها

### خطأ: "API Key not valid"
- تأكد من نسخ المفتاح بشكل صحيح
- تحقق من أن الحساب مفعل

### خطأ: "Model load failed"
- تأكد من أن رابط النموذج صحيح
- تحقق من أن الملف في الصيغة الصحيحة (model.json)

### خطأ: "GitHub authentication failed"
- تأكد من صحة التوكن
- تحقق من انتهاء صلاحية التوكن

## الدعم والمساعدة

للأسئلة والمشاكل، يرجى التحقق من:
1. إعدادات API والمفاتيح
2. اتصال الإنترنت
3. متصفح محدث يدعم WebGL

## الترخيص

مفتوح المصدر - للاستخدام الشخصي والتعليمي

---

**ملاحظة مهمة:** هذا التطبيق يستخدم في المحاكاة الورقية (Paper Trading) وليس للتداول الفعلي. استخدم على مسؤوليتك الخاصة.
