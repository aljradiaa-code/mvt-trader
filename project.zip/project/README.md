# MVT-VRL Trader - Multi-Timeframe Vision Reinforcement Learning Trading System

**Autonomous AI-Powered Trading Application**

A sophisticated trading application that combines multi-timeframe technical analysis with TensorFlow.js neural networks to automatically execute paper trading strategies.

## ✨ Key Features

### Live Trading
- Real-time data from TwelveData API
- 4 simultaneous timeframes (5M, 15M, 1H, 4H)
- Automatic trade execution
- Stop Loss & Take Profit management
- Open/Closed trades monitoring

### Backtesting Engine
- CSV file support
- Historical data analysis
- Adjustable playback speed (0.1x - 5x)
- Performance statistics
- Detailed trade reports

### Smart Analytics
- Win rate calculation
- Profit/Loss analysis
- Risk:Reward ratio
- Per-rule performance tracking
- Comprehensive dashboards

### GitHub Integration
- Auto-upload trade logs
- Model synchronization
- Automatic model updates
- Private data storage

### Advanced Features
- 50-candle circular buffer
- Autonomous rule discovery
- Multi-symbol support
- Settings import/export
- Works offline (after initial load)

---

## 🚀 Quick Start

### Installation

```bash
# Clone or download the project
git clone <repository-url>
cd MVT-VRL-Trader

# Install dependencies
npm install

# Start development server
npm run dev
```

Open browser: http://localhost:5173

### First Steps

1. **Add API Key** (5 seconds)
   ```
   Home → Settings → API Keys → TwelveData
   Paste: 6a1f3b95b77841ceb3beb709fb50763e
   ```

2. **Start Trading** (2 clicks)
   ```
   Home → Start Trading → Start
   ```

3. **Test Strategy** (1 minute)
   ```
   Home → Run Backtest → Upload CSV → Start
   ```

---

## 📋 Pages Overview

| Page | Features |
|------|----------|
| **Live Trading** | Real-time charts, automatic trades, live stats |
| **Backtesting** | CSV upload, speed control, performance metrics |
| **Statistics** | Win rate, P&L analysis, rule performance |
| **Settings** | API configuration, trading parameters |
| **GitHub Sync** | Upload trades, download models |

---

## 🛠️ Technology Stack

- **Frontend**: React 18 + TypeScript + Tailwind CSS
- **AI/ML**: TensorFlow.js
- **Charting**: Lightweight Charts
- **Mobile**: Capacitor (for APK generation)
- **Data**: TwelveData API
- **Storage**: localStorage + GitHub

---

## 📱 Building APK

### Automatic (Easy)
```bash
chmod +x build-apk.sh
./build-apk.sh
```

### Manual
```bash
npm run build
npx cap init --web-dir=dist
npx cap add android
npx cap sync
cd android && ./gradlew assembleDebug
```

APK location: `android/app/build/outputs/apk/debug/app-debug.apk`

---

## 📊 Data Format

### CSV for Backtesting
```csv
DateTime,Open,High,Low,Close,Volume
2024-01-01 09:00:00,1.0800,1.0850,1.0790,1.0820,5000
2024-01-01 09:05:00,1.0820,1.0860,1.0815,1.0845,4500
```

### GitHub Trade Logs
```json
{
  "timestamp": "2024-06-04T10:30:00Z",
  "trades": [
    {
      "id": "trade_001",
      "entryPrice": 1.0850,
      "exitPrice": 1.0875,
      "profitLoss": 25,
      "rule": "Rule_LONG_5_15"
    }
  ],
  "summary": {
    "total": 10,
    "wins": 6,
    "losses": 4
  }
}
```

---

## 🔑 API Configuration

### TwelveData
```
API Endpoint: https://api.twelvedata.com
Supported: Forex, Crypto, Stocks
Free Tier: 800 calls/day
Key: 6a1f3b95b77841ceb3beb709fb50763e
```

### GitHub
```
Endpoint: https://api.github.com
Create Token: https://github.com/settings/tokens
Permissions: repo, workflow
```

---

## 💾 Data Storage

All data stored locally in browser:
```javascript
localStorage:
├── trades          // All trades
├── rules          // Discovered rules
├── app_settings   // User configuration
├── twelvedata_api // API key
└── github_token   // GitHub token
```

---

## 🎯 Features in Detail

### Multi-Timeframe Analysis
- **5M**: Entry confirmation & micro patterns
- **15M**: Execution zone & liquidity
- **1H**: Intermediate structure
- **4H**: Macro structure & trend

### Autonomous Rule Generation
System automatically discovers trading patterns:
- Rule_LONG_5_15_60
- Rule_SHORT_15_60_240
- Rule_SCALP_5M
- etc.

Each rule tracks:
- Win rate
- Average profit/loss
- Total profit
- Sample size

### Paper Trading
- Virtual account: $10,000 (customizable)
- 2% risk per trade (configurable)
- SL/TP automatic calculation
- Trade history tracking

---

## 📈 Performance Metrics

The app tracks:
- **Win Rate**: % of profitable trades
- **Profit Factor**: Win size / Loss size
- **Max Drawdown**: Peak-to-trough decline
- **ROI**: Return on investment
- **Sharpe Ratio**: Risk-adjusted returns

---

## 🔒 Privacy & Security

- ✅ 100% local data storage
- ✅ No central servers
- ✅ GitHub integration optional
- ✅ No personal data collection
- ✅ No ads or tracking

---

## ⚙️ Configuration

### Trading Settings
```javascript
{
  balance: 10000,           // Initial account balance
  riskPercent: 2,           // Risk per trade (%)
  timeframes: [5,15,60,240] // Active timeframes
}
```

### API Configuration
```javascript
{
  provider: 'twelvedata',
  apiKey: 'YOUR_KEY',
  enabled: true
}
```

---

## 🐛 Troubleshooting

| Issue | Solution |
|-------|----------|
| "Port already in use" | `npm run dev -- --port 3000` |
| "Cannot load model" | Check TensorFlow.js URL format |
| "API Key invalid" | Verify no extra spaces |
| "Build failed" | Run `npm run lint` |

---

## 📚 Documentation Files

- **README_AR.md** - Complete Arabic guide
- **QUICKSTART.md** - 5-minute quick start
- **SETUP.md** - Detailed installation
- **FILE_STRUCTURE.md** - Code organization
- **GITHUB_SETUP.md** - GitHub integration

---

## 📦 Project Structure

```
src/
├── pages/              # 5 main pages
│   ├── LiveTradingPage.tsx
│   ├── BacktestPage.tsx
│   ├── StatisticsPage.tsx
│   ├── SettingsPage.tsx
│   └── GithubSyncPage.tsx
├── components/         # UI components
│   ├── ChartComponent.tsx
│   ├── TradePanel.tsx
│   └── RulesPanel.tsx
├── services/          # Business logic
│   ├── tensorflowService.ts
│   ├── dataService.ts
│   ├── candleBuffer.ts
│   └── tradeManager.ts
├── types.ts           # TypeScript definitions
└── App.tsx            # Main router
```

---

## 🚀 Build Commands

```bash
# Development
npm run dev

# Production build
npm run build

# Type checking
npm run typecheck

# Linting
npm run lint

# Preview production build
npm run preview
```

---

## 🔗 Useful Links

- TwelveData API: https://twelvedata.com/docs
- TensorFlow.js: https://www.tensorflow.org/js
- Lightweight Charts: https://tradingview.github.io/lightweight-charts/
- Capacitor: https://capacitorjs.com

---

## ⚖️ Legal Notice

- **Paper Trading Only**: No real money trading
- **Use at Your Own Risk**: Not financial advice
- **Testing Purpose**: For educational use
- **No Warranty**: Use as-is

---

## 📄 License

Open Source - Educational & Personal Use

---

## 🙏 Credits

Built with:
- React & TypeScript
- TensorFlow.js
- Lightweight Charts
- Tailwind CSS
- Capacitor

---

**Version:** 1.0.0  
**Last Updated:** June 2024  
**Status:** Ready for Production
