# دليل بناء تطبيق Android APK - MVT-VRL Trader

## المتطلبات الأساسية

### 1. Java Development Kit (JDK)

```bash
# على Windows
# حمّل من: https://www.oracle.com/java/technologies/javase-jdk17-downloads.html

# على Linux/Mac
# Ubuntu/Debian:
sudo apt-get install openjdk-11-jdk

# macOS:
brew install openjdk@11

# التحقق من التثبيت:
java -version
```

**الحد الأدنى**: Java 11
**الموصى به**: Java 17

### 2. Android SDK

```bash
# حمّل Android Studio من:
# https://developer.android.com/studio

# أو استخدم Command Line Tools:
# https://developer.android.com/studio#command-tools

# بعد التثبيت، عيّن المتغيرات:
# Windows:
setx ANDROID_SDK_ROOT "C:\Android\sdk"

# Linux/Mac:
export ANDROID_SDK_ROOT=$HOME/Android/sdk
export PATH=$PATH:$ANDROID_SDK_ROOT/tools:$ANDROID_SDK_ROOT/platform-tools
```

### 3. Gradle

تم تضمينه في المشروع (Gradle Wrapper)

---

## الخطوات السريعة

### على Windows (الطريقة السهلة):

```batch
# 1. فك الضغط عن المشروع
# 2. افتح Command Prompt أو PowerShell
# 3. انتقل إلى مجلد المشروع
cd C:\path\to\MVT-VRL-Trader

# 4. استخدم السكريبت
build-and-deploy.bat full
```

### على Linux/Mac:

```bash
# 1. فك الضغط عن المشروع
# 2. افتح Terminal
# 3. انتقل إلى مجلد المشروع
cd /path/to/MVT-VRL-Trader

# 4. اعطِ صلاحية التنفيذ للسكريبت
chmod +x build-and-deploy.sh

# 5. استخدم السكريبت
./build-and-deploy.sh full
```

---

## الأوامر المتاحة

### بناء النسخة الويب فقط

```bash
# Linux/Mac
./build-and-deploy.sh web

# Windows
build-and-deploy.bat web
```

**التأثير**: ينشئ مجلد `dist/` مع الملفات الثابتة

### مزامنة مع Android

```bash
# Linux/Mac
./build-and-deploy.sh sync

# Windows
build-and-deploy.bat sync
```

**التأثير**: نسخ الملفات من `dist/` إلى `android/`

### بناء APK Debug

```bash
# Linux/Mac
./build-and-deploy.sh debug

# Windows
build-and-deploy.bat debug
```

**ما يفعله**:
1. بناء النسخة الويب
2. مزامنة مع Android
3. بناء APK Debug
4. ملف الإخراج: `android/app/build/outputs/apk/debug/app-debug.apk`

### بناء APK Release

```bash
# Linux/Mac
./build-and-deploy.sh release

# Windows
build-and-deploy.bat release
```

**ملاحظة**: يتطلب Signing Configuration
**ملف الإخراج**: `android/app/build/outputs/apk/release/app-release.apk`

### تثبيت على الهاتف

```bash
# Linux/Mac
./build-and-deploy.sh install

# Windows
build-and-deploy.bat install
```

**المتطلبات**:
- توصيل الهاتف بالحاسوب
- تفعيل USB Debugging على الهاتف
- تثبيت adb (أدوات منصة Android)

### البناء الكامل

```bash
# Linux/Mac
./build-and-deploy.sh full

# Windows
build-and-deploy.bat full
```

**يقوم بـ**:
1. بناء النسخة الويب
2. مزامنة مع Android
3. بناء APK Debug
4. تثبيت على الهاتف

---

## تفعيل USB Debugging على الهاتف

### للأجهزة بنظام Android:

1. **الإعدادات** → **عن الهاتف**
2. اضغط **رقم الإصدار** 7 مرات متتالية
3. عودة للإعدادات → ستجد **خيارات المطور** أو **Developer Options**
4. فعّل **USB Debugging**
5. توصيل الهاتف بالحاسوب

### التحقق من الاتصال:

```bash
adb devices
```

يجب أن تري اسم الجهاز في القائمة

---

## حل المشاكل الشائعة

### المشكلة: "Java not found"
```
الحل:
1. ثبّت JDK 11 أو أحدث
2. تأكد من إضافة Java إلى PATH
3. أعد تشغيل Terminal بعد التثبيت
```

### المشكلة: "Android SDK not found"
```
الحل:
1. عيّن ANDROID_SDK_ROOT بشكل صحيح:
   
   Linux/Mac:
   export ANDROID_SDK_ROOT=$HOME/Android/sdk
   
   Windows:
   setx ANDROID_SDK_ROOT "C:\Android\sdk"

2. تأكد من وجود المجلد
```

### المشكلة: "Gradle build failed"
```
الحل:
1. نظّف المشروع: ./build-and-deploy.sh clean
2. احذف node_modules: rm -rf node_modules
3. أعد التثبيت: npm install
4. جرب البناء مرة أخرى
```

### المشكلة: "Device not found"
```
الحل:
1. تأكد من تفعيل USB Debugging
2. جرب: adb kill-server ثم adb devices
3. حاول توصيل الهاتف مرة أخرى
```

### المشكلة: "Permission denied" على Linux/Mac
```
الحل:
اعطِ صلاحية التنفيذ للسكريبت:
chmod +x build-and-deploy.sh
```

---

## إنشاء Signed APK (Release)

للنشر على Google Play، تحتاج APK موقّع:

### الخطوة 1: إنشاء keystore

```bash
keytool -genkey -v -keystore mvt-trader.keystore \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias mvt-trader
```

### الخطوة 2: إضافة البيانات إلى gradle.properties

```gradle
# android/gradle.properties

MYAPP_RELEASE_STORE_FILE=../mvt-trader.keystore
MYAPP_RELEASE_STORE_PASSWORD=your_password
MYAPP_RELEASE_KEY_ALIAS=mvt-trader
MYAPP_RELEASE_KEY_PASSWORD=your_password
```

### الخطوة 3: تحديث build.gradle

```gradle
# android/app/build.gradle

signingConfigs {
    release {
        storeFile file(MYAPP_RELEASE_STORE_FILE)
        storePassword MYAPP_RELEASE_STORE_PASSWORD
        keyAlias MYAPP_RELEASE_KEY_ALIAS
        keyPassword MYAPP_RELEASE_KEY_PASSWORD
    }
}

buildTypes {
    release {
        signingConfig signingConfigs.release
    }
}
```

### الخطوة 4: بناء Release

```bash
./build-and-deploy.sh release
```

---

## حجم APK والتحسينات

### حجم APK الحالي:
- Debug APK: ~40-50 MB
- Release APK: ~35-45 MB

### طرق التحسين:

```gradle
# في android/app/build.gradle

buildTypes {
    release {
        minifyEnabled true
        proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        
        ndk {
            abiFilters 'arm64-v8a', 'armeabi-v7a'
        }
    }
}
```

---

## اختبار التطبيق

### على الجهاز:

```bash
# 1. ثبت التطبيق
./build-and-deploy.sh install

# 2. افتح التطبيق
adb shell am start -n com.mvtrader.app/.MainActivity

# 3. شاهد السجلات
adb logcat | grep -i mvtrader
```

### اختبر جميع الميزات:

- [ ] التداول الحي
- [ ] الباك تست
- [ ] الإحصائيات
- [ ] الإعدادات
- [ ] GitHub Sync
- [ ] حفظ البيانات محلياً

---

## النشر على Google Play

### المتطلبات:

1. حساب Google Developer (رسم واحد فقط: $25)
2. APK موقّع (Release)
3. صور وحصة ترويجية
4. وصف التطبيق

### الخطوات:

1. اذهب إلى [Google Play Console](https://play.google.com/console)
2. أنشئ تطبيق جديد
3. أكمل البيانات الأساسية
4. رفع APK Release
5. أضف النسخة الأولى للاختبار المفتوح
6. اطلب المراجعة

---

## المراجع المفيدة

- [Capacitor Android Documentation](https://capacitorjs.com/docs/android)
- [Android Developer Guide](https://developer.android.com/guide)
- [Gradle Build System](https://gradle.org/)
- [Google Play Console Help](https://support.google.com/googleplay/android-developer)

---

## أسئلة شائعة

**س: هل يمكن تطوير التطبيق بدون Android Studio؟**
أ: نعم، يمكنك استخدام Command Line Tools فقط

**س: ما هو الحد الأدنى لإصدار Android المدعوم؟**
أ: Android 8.0 (API 26)

**س: هل يمكن استخدام جهاز محاكاة (Emulator) بدلاً من هاتف فعلي؟**
أ: نعم، استخدم Android Emulator من Android Studio

**س: كيف أتحديث التطبيق؟**
أ: غيّر رقم الإصدار في capacitor.config.json وأعِد بناء

---

**النسخة**: 1.0.0
**آخر تحديث**: June 2024
