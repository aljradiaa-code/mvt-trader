# خريطة الملفات - MVT-VRL Trader

## هيكل المشروع

```
MVT-VRL-Trader/
├── src/
│   ├── pages/
│   │   ├── LiveTradingPage.tsx        # صفحة التداول الحي
│   │   ├── BacktestPage.tsx           # صفحة الاختبار العكسي
│   │   ├── StatisticsPage.tsx         # صفحة الإحصائيات
│   │   ├── SettingsPage.tsx           # صفحة الإعدادات
│   │   └── GithubSyncPage.tsx         # صفحة مزامنة GitHub
│   │
│   ├── components/
│   │   ├── ChartComponent.tsx         # رسم الشموع
│   │   ├── TradePanel.tsx             # عرض الصفقات المفتوحة
│   │   └── RulesPanel.tsx             # عرض قوانين التداول
│   │
│   ├── services/
│   │   ├── tensorflowService.ts       # تحميل وتشغيل النموذج
│   │   ├── dataService.ts             # جلب البيانات من TwelveData
│   │   ├── candleBuffer.ts            # إدارة المخزن المؤقت للشموع
│   │   └── tradeManager.ts            # إدارة الصفقات والقوانين
│   │
│   ├── types.ts                       # تعريفات TypeScript
│   ├── App.tsx                        # التطبيق الرئيسي
│   ├── main.tsx                       # نقطة الدخول
│   └── index.css                      # الأنماط العامة
│
├── dist/                              # النسخة المُبنية (بعد npm run build)
├── android/                           # مشروع Android (بعد npx cap add android)
│
├── package.json                       # الحزم والبرامج النصية
├── capacitor.config.json              # إعدادات Capacitor
├── tailwind.config.js                 # إعدادات Tailwind CSS
├── tsconfig.json                      # إعدادات TypeScript
├── vite.config.ts                     # إعدادات Vite
│
├── README_AR.md                       # دليل مفصل بالعربية
├── SETUP.md                           # خطوات التثبيت
├── build-apk.sh                       # سكريبت بناء APK
└── FILE_STRUCTURE.md                  # هذا الملف
```

---

## شرح الملفات الرئيسية

### `src/pages/`

#### `LiveTradingPage.tsx` (صفحة التداول الحي)
```javascript
المسؤوليات:
✓ جلب البيانات الحية من API
✓ تحديث الرسم البياني في الوقت الفعلي
✓ تشغيل النموذج للتحليل
✓ إنشاء صفقات تلقائية
✓ إدارة الصفقات المفتوحة والمغلقة

المتغيرات الرئيسية:
- apiKey: مفتاح TwelveData
- selectedTimeframe: الفريم المختار (5, 15, 60, 240)
- trades: قائمة الصفقات
- stats: إحصائيات الحساب
```

#### `BacktestPage.tsx` (صفحة الاختبار العكسي)
```javascript
المسؤوليات:
✓ تحميل ملفات CSV
✓ تشغيل الاختبار على البيانات التاريخية
✓ عرض النتائج والإحصائيات
✓ التحكم في سرعة الحركة

المتغيرات الرئيسية:
- file: الملف المحمل
- result: نتائج الاختبار
- speed: سرعة حركة الوقت (1x-5x)
```

#### `StatisticsPage.tsx` (صفحة الإحصائيات)
```javascript
المسؤوليات:
✓ عرض مقاييس الأداء الشاملة
✓ رسوم بيانية للأداء
✓ إحصائيات كل قاعدة تداول
✓ نسب الربح والخسارة

البيانات المعروضة:
- معدل الفوز (Win Rate)
- الربح الإجمالي (Total Profit)
- نسبة المخاطرة:الربح (Risk:Reward)
- أداء كل قاعدة
```

#### `SettingsPage.tsx` (صفحة الإعدادات)
```javascript
المسؤوليات:
✓ إعدادات التداول
✓ إدارة مفاتيح API
✓ إعدادات النموذج
✓ تصدير/استيراد الإعدادات

الإعدادات المتاحة:
- الرصيد الابتدائي
- نسبة المخاطرة
- الفريمات النشطة
- مفاتيح API
- رابط النموذج
```

#### `GithubSyncPage.tsx` (صفحة GitHub)
```javascript
المسؤوليات:
✓ رفع سجلات الصفقات
✓ تحميل النماذج المحدثة
✓ إدارة بيانات GitHub

العمليات:
- handleUploadTrades: رفع الصفقات
- handleDownloadModel: تحميل النموذج
- saveCredentials: حفظ بيانات GitHub
```

---

### `src/services/`

#### `tensorflowService.ts` (خدمة النموذج الذكي)
```javascript
الدوال الرئيسية:
- loadModel(url): تحميل النموذج من رابط
- getModel(): الحصول على النموذج المحمل
- analyzeCandles(candles): تحليل الشموع
- prepareInput(candles): تحضير البيانات

النتيجة:
{
  signal: 'buy' | 'sell' | 'hold',
  confidence: 0-1,
  strength: 0-1
}
```

#### `dataService.ts` (خدمة جلب البيانات)
```javascript
الدوال الرئيسية:
- fetchCandles(apiKey, symbol, interval, limit)
- fetchMultipleTimeframes(apiKey, symbol, timeframes)

تنسيق البيانات:
{
  time: timestamp,
  o: open price,
  h: high price,
  l: low price,
  c: close price,
  v: volume
}
```

#### `candleBuffer.ts` (إدارة الذاكرة المؤقتة)
```javascript
الدوال الرئيسية:
- addCandle(timeframe, candle): إضافة شمعة جديدة
- getCandles(timeframe): جلب آخر 50 شمعة
- getLatestCandle(timeframe): آخر شمعة

الحد الأقصى: 50 شمعة لكل فريم (Circular Buffer)
```

#### `tradeManager.ts` (إدارة الصفقات)
```javascript
الدوال الرئيسية:
- addTrade(trade): إضافة صفقة جديدة
- closeTrade(tradeId, exitPrice): إغلاق صفقة
- getTrades(): جلب جميع الصفقات
- getRules(): جلب القوانين

التخزين:
- localStorage['trades']: الصفقات
- localStorage['rules']: القوانين
```

---

### `src/components/`

#### `ChartComponent.tsx` (رسم الشموع)
```javascript
المسؤوليات:
✓ عرض رسم بياني تفاعلي
✓ تحديث البيانات
✓ معالجة تغيير حجم النافذة

المكتبة:
lightweight-charts v4.1.1
```

#### `TradePanel.tsx` (عرض الصفقات)
```javascript
المسؤوليات:
✓ عرض الصفقات المفتوحة
✓ الزر لإغلاق الصفقات
✓ عرض البيانات (دخول، هدف، استوب)
```

#### `RulesPanel.tsx` (عرض القوانين)
```javascript
المسؤوليات:
✓ عرض جميع القوانين المكتشفة
✓ أداء كل قاعدة
✓ إحصائيات الفوز والخسارة
```

---

## المتغيرات المهمة في localStorage

```javascript
// API Keys
localStorage.setItem('twelvedata_api', apiKey);

// السجلات
localStorage.setItem('trades', JSON.stringify(trades));
localStorage.setItem('rules', JSON.stringify(rules));

// الإعدادات
localStorage.setItem('app_settings', JSON.stringify(settings));

// GitHub
localStorage.setItem('github_repo', repoUrl);
localStorage.setItem('github_token', token);

// النموذج
localStorage.setItem('model_url', modelUrl);
```

---

## تدفق البيانات

```
API (TwelveData)
    ↓
fetchCandles() → dataService
    ↓
candleBuffer (آخر 50 شمعة)
    ↓
analyzeCandles() → tensorflowService (TensorFlow.js)
    ↓
tradeManager (إنشاء صفقات جديدة)
    ↓
localStorage (حفظ الصفقات)
    ↓
GitHub (رفع السجلات)
```

---

## نقاط المزامنة الرئيسية

```
1️⃣ جلب البيانات (كل 5 ثواني)
   - الحصول على آخر 50 شمعة
   - تحديث المخزن المؤقت

2️⃣ التحليل (عند وصول بيانات جديدة)
   - تشغيل النموذج
   - اكتشاف الإشارات

3️⃣ التنفيذ (عند الإشارة)
   - إنشاء صفقة جديدة
   - حفظ في localStorage

4️⃣ المزامنة مع GitHub
   - رفع الصفقات (يدوي)
   - تحميل النموذج (يدوي)
```

---

## البيئات المدعومة

```
تطوير (Development):
npm run dev

إنتاج (Production):
npm run build

جودة الكود:
npm run lint
npm run typecheck
```

---

## الحد الأدنى من الحزم

```json
{
  "core": [
    "@tensorflow/tfjs",
    "react",
    "react-dom"
  ],
  "charting": [
    "lightweight-charts",
    "recharts"
  ],
  "ui": [
    "lucide-react",
    "tailwindcss"
  ],
  "mobile": [
    "@capacitor/core",
    "@capacitor/cli",
    "@capacitor/android"
  ]
}
```

---

## ملاحظات مهمة

- ✅ جميع البيانات تُحفظ محلياً في localStorage
- ✅ يعمل بدون إنترنت بعد التحميل الأول
- ✅ المزامنة مع GitHub اختيارية
- ✅ النموذج يعمل في المتصفح (لا يحتاج سيرفر)
- ⚠️ حد أقصى لـ localStorage حوالي 5-10MB

---

**آخر تحديث:** June 2024
