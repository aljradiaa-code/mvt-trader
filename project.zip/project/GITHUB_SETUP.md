# نموذج GitHub - MVT-VRL Trader Integration

## إعداد مستودع GitHub للمزامنة

### الخطوة 1: إنشاء المستودع

```bash
# على GitHub (عبر الويب)
1. اذهب إلى https://github.com/new
2. اسم المستودع: trading-logs
3. الخصوصية: Private (إذا أردت)
4. اضغط "Create repository"
```

### الخطوة 2: إعداد المجلدات والملفات الأولية

```bash
git clone https://github.com/YOUR_USERNAME/trading-logs.git
cd trading-logs

# إنشاء المجلدات
mkdir logs
mkdir releases
mkdir models

# إنشاء ملفات أولية
touch logs/.gitkeep
touch releases/.gitkeep
touch models/.gitkeep
touch logs/README.md
touch releases/README.md

# إضافة ملف التعليمات
cat > README.md << 'EOF'
# MVT-VRL Trading Logs

## المحتويات

- **logs/** - سجلات التداول اليومية
- **models/** - النماذج المدربة
- **releases/** - إصدارات النموذج المختلفة

## الاستخدام

1. التطبيق يرفع الصفقات تلقائياً إلى `logs/`
2. استخدم GitHub Actions لإعادة التدريب
3. حمّل النموذج المحدث من `releases/`
EOF

git add .
git commit -m "Initial setup"
git push origin main
```

### الخطوة 3: إنشاء GitHub Personal Token

```
1. اذهب إلى: https://github.com/settings/tokens
2. اضغط: "Generate new token (classic)"
3. اعطِ الصلاحيات:
   ✓ repo (Full control of private repositories)
   ✓ workflow (Update GitHub Action workflows)
   ✓ gist (Create gists)
4. اضغط: "Generate token"
5. انسخ التوكن (لن تراه مرة أخرى)
6. احفظه في مكان آمن
```

### الخطوة 4: إضافة GitHub Action للتدريب التلقائي

أنشئ ملف: `.github/workflows/train.yml`

```yaml
name: Auto-Train Model

on:
  push:
    paths:
      - 'logs/**'

jobs:
  train:
    runs-on: ubuntu-latest
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.10'
      
      - name: Install dependencies
        run: |
          pip install tensorflow numpy pandas scikit-learn
      
      - name: Process logs and train
        run: |
          python scripts/train_model.py
      
      - name: Commit and push model
        run: |
          git config --global user.email "bot@example.com"
          git config --global user.name "Training Bot"
          git add models/
          git commit -m "Auto-trained model - $(date)" || echo "No changes"
          git push
      
      - name: Create Release
        uses: softprops/action-gh-release@v1
        if: startsWith(github.ref, 'refs/tags/')
        with:
          files: models/model.zip
```

---

## هيكل المستودع النهائي

```
trading-logs/
├── README.md                 # ملف التوثيق
├── .gitignore
├── .github/
│   └── workflows/
│       └── train.yml         # GitHub Action التدريب
├── logs/
│   ├── 2024-06-01_trades.json
│   ├── 2024-06-02_trades.json
│   └── README.md
├── models/
│   ├── model.json
│   ├── model.weights.bin
│   └── metadata.json
└── releases/
    ├── model-v1.0.zip
    ├── model-v1.1.zip
    └── README.md
```

---

## صيغة ملف السجل (logs/YYYY-MM-DD_trades.json)

```json
{
  "date": "2024-06-04",
  "timestamp": "2024-06-04T10:30:00Z",
  "account": {
    "initial_balance": 10000,
    "final_balance": 10250
  },
  "trades": [
    {
      "id": "trade_001",
      "symbol": "EURUSD",
      "timeframe": "5M",
      "entry_price": 1.0850,
      "exit_price": 1.0875,
      "entry_time": "2024-06-04T10:00:00Z",
      "exit_time": "2024-06-04T10:15:00Z",
      "quantity": 1.0,
      "profit_loss": 25,
      "profit_loss_percent": 0.24,
      "rule": "Rule_LONG_5_15_60",
      "status": "closed",
      "stop_loss": 1.0820,
      "take_profit": 1.0890
    }
  ],
  "summary": {
    "total_trades": 5,
    "closed_trades": 5,
    "open_trades": 0,
    "win_trades": 3,
    "lose_trades": 2,
    "win_rate": 60,
    "total_profit": 250,
    "max_drawdown": 50
  }
}
```

---

## نموذج ملف النموذج (model/metadata.json)

```json
{
  "version": "1.0.0",
  "created": "2024-06-04T10:00:00Z",
  "training": {
    "epochs": 100,
    "batch_size": 32,
    "loss": 0.0234,
    "accuracy": 0.856
  },
  "architecture": {
    "input_shape": [1, 250],
    "output_shape": [1, 2],
    "layers": [
      "LSTM(64)",
      "Dropout(0.2)",
      "Dense(32, ReLU)",
      "Dense(2, Sigmoid)"
    ]
  },
  "data": {
    "training_samples": 10000,
    "validation_samples": 2000,
    "features": ["open", "high", "low", "close", "volume"]
  },
  "performance": {
    "precision": 0.87,
    "recall": 0.83,
    "f1_score": 0.85
  }
}
```

---

## في التطبيق: استخدام GitHub

### 1. إدخال البيانات الأولية

```javascript
// في SettingsPage
const settings = {
  githubToken: "ghp_xxxxxxxxxxxxx",
  modelUrl: "https://raw.githubusercontent.com/username/trading-logs/main/models/model.json"
}
```

### 2. رفع الصفقات

```javascript
// في GithubSyncPage
const uploadTrades = async () => {
  const fileName = `logs/${today}_trades.json`;
  const content = btoa(JSON.stringify(tradesData));
  
  const response = await fetch(
    `https://api.github.com/repos/${owner}/${repo}/contents/${fileName}`,
    {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        message: `Daily trades - ${today}`,
        content: content
      })
    }
  );
}
```

### 3. تحميل النموذج

```javascript
// في GithubSyncPage
const downloadModel = async () => {
  const releases = await fetch(
    `https://api.github.com/repos/${owner}/${repo}/releases/latest`,
    { headers: { 'Authorization': `Bearer ${token}` } }
  );
  
  const latestModel = releases.assets
    .find(a => a.name.includes('model'));
  
  await fetch(latestModel.browser_download_url);
}
```

---

## الخطوات الموصى بها

### يومياً:
- ✅ التطبيق يرفع الصفقات تلقائياً (إذا فعلت Upload)

### أسبوعياً:
- ✅ فحص الأداء في GitHub
- ✅ تحديث النموذج إذا كان هناك تحسن

### شهرياً:
- ✅ مراجعة الإحصائيات الكاملة
- ✅ إعادة تدريب النموذج
- ✅ تحميل النسخة الجديدة

---

## استكشاف الأخطاء

### المشكلة: "Authentication failed"
```
✓ تحقق من صحة التوكن
✓ تأكد من عدم انتهاء صلاحيته
✓ تحقق من الصلاحيات (repo, workflow)
```

### المشكلة: "Repository not found"
```
✓ تحقق من رابط المستودع
✓ تأكد من أنك Owner أو لديك صلاحيات Write
✓ جرب رابط مختلف
```

### المشكلة: "File already exists"
```
✓ الملفات موجودة بالفعل - هذا طبيعي
✓ ستُستبدل عند الرفع مجدداً
```

---

## أمثلة إضافية

### رفع ملف نموذج

```bash
# من Terminal
curl -X PUT \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"message":"Upload model","content":"BASE64_CONTENT"}' \
  https://api.github.com/repos/USERNAME/trading-logs/contents/models/model.json
```

### جلب آخر سجلات

```javascript
const getLogs = async (owner, repo, token) => {
  const response = await fetch(
    `https://api.github.com/repos/${owner}/${repo}/contents/logs`,
    { headers: { 'Authorization': `Bearer ${token}` } }
  );
  
  const files = await response.json();
  return files.filter(f => f.name.endsWith('.json'));
}
```

---

## الخلاصة

✅ كل شيء اختياري - التطبيق يعمل بدون GitHub  
✅ GitHub للمزامنة والتدريب فقط  
✅ جميع البيانات آمنة وخاصة  
✅ يمكن إعادة التدريب تلقائياً  
✅ تحديث سهل للنموذج  

---

**ملاحظة:** احفظ التوكن في مكان آمن ولا تشاركه مع أحد!
