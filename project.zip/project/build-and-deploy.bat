@echo off
REM MVT-VRL Trader - Build & Deploy Script for Windows
REM نسخة شاملة لبناء وتوزيع التطبيق على Windows

setlocal enabledelayedexpansion

set "RED=[91m"
set "GREEN=[92m"
set "YELLOW=[93m"
set "BLUE=[94m"
set "NC=[0m"

echo.
echo %BLUE%════════════════════════════════════════════════════════════════%NC%
echo %BLUE%  MVT-VRL Trader - Build ^& Deploy for Windows%NC%
echo %BLUE%════════════════════════════════════════════════════════════════%NC%
echo.

if "%1"=="" (
    goto :show_help
) else if "%1"=="web" (
    goto :build_web
) else if "%1"=="sync" (
    goto :update_capacitor
) else if "%1"=="debug" (
    goto :build_apk_debug
) else if "%1"=="release" (
    goto :build_apk_release
) else if "%1"=="install" (
    goto :install_apk
) else if "%1"=="clean" (
    goto :clean
) else if "%1"=="full" (
    goto :full_build
) else (
    goto :show_help
)

:build_web
echo %GREEN%[+] بناء النسخة الويب%NC%
echo.
echo   [*] تثبيت الحزم...
call npm install
echo.
echo   [*] بناء النسخة الإنتاجية...
call npm run build
if exist dist (
    echo %GREEN%[✓] تم بناء النسخة الويب بنجاح%NC%
) else (
    echo %RED%[✗] فشل بناء النسخة الويب%NC%
    exit /b 1
)
goto :end

:update_capacitor
echo %GREEN%[+] تحديث Capacitor%NC%
echo.
echo   [*] مزامنة الملفات مع Android...
call npx cap sync
echo %GREEN%[✓] تم تحديث Capacitor%NC%
goto :end

:build_apk_debug
echo %GREEN%[+] بناء APK Debug%NC%
echo.
call :build_web
call :update_capacitor
echo.
echo   [*] الانتقال إلى مجلد android...
cd android
echo.
echo   [*] تنظيف المشاريع السابقة...
call gradlew.bat clean
echo.
echo   [*] بناء APK Debug...
call gradlew.bat assembleDebug
cd ..
echo.
if exist android\app\build\outputs\apk\debug\app-debug.apk (
    for %%F in (android\app\build\outputs\apk\debug\app-debug.apk) do set "APK_SIZE=%%~zF"
    echo %GREEN%[✓] تم بناء APK Debug بنجاح%NC%
    echo   الملف: android\app\build\outputs\apk\debug\app-debug.apk
) else (
    echo %RED%[✗] فشل بناء APK Debug%NC%
    exit /b 1
)
goto :end

:build_apk_release
echo %GREEN%[+] بناء APK Release%NC%
echo.
call :build_web
call :update_capacitor
echo.
echo   [*] الانتقال إلى مجلد android...
cd android
echo   [*] بناء APK Release...
call gradlew.bat assembleRelease
cd ..
echo.
if exist android\app\build\outputs\apk\release\app-release.apk (
    echo %GREEN%[✓] تم بناء APK Release بنجاح%NC%
    echo   الملف: android\app\build\outputs\apk\release\app-release.apk
) else (
    echo %YELLOW%[!] لم يتم العثور على APK Release%NC%
)
goto :end

:install_apk
echo %GREEN%[+] تثبيت APK على الهاتف%NC%
echo.
echo   [*] جاري البحث عن الأجهزة المتصلة...
adb devices
echo.
echo   [*] جاري التثبيت...
adb install -r android\app\build\outputs\apk\debug\app-debug.apk
if %errorlevel% equ 0 (
    echo %GREEN%[✓] تم التثبيت بنجاح%NC%
) else (
    echo %RED%[✗] فشل التثبيت%NC%
    exit /b 1
)
goto :end

:clean
echo %GREEN%[+] تنظيف المشاريع%NC%
echo.
echo   [*] حذف dist/...
if exist dist rmdir /s /q dist
echo   [*] تنظيف Gradle...
cd android
call gradlew.bat clean
cd ..
echo %GREEN%[✓] تم التنظيف%NC%
goto :end

:full_build
echo %BLUE%════════════════════════════════════════════════════════════════%NC%
echo   البناء الكامل: Web + Sync + APK Debug + Install
echo %BLUE%════════════════════════════════════════════════════════════════%NC%
echo.
call :build_web
echo.
call :update_capacitor
echo.
call :build_apk_debug
echo.
call :install_apk
echo.
echo %GREEN%════════════════════════════════════════════════════════════════%NC%
echo %GREEN%[✓] اكتمل البناء الكامل بنجاح!%NC%
echo %GREEN%════════════════════════════════════════════════════════════════%NC%
goto :end

:show_help
echo %BLUE%════════════════════════════════════════════════════════════════%NC%
echo   الأوامر المتاحة:
echo %BLUE%════════════════════════════════════════════════════════════════%NC%
echo.
echo   %YELLOW%web%NC%            - بناء النسخة الويب فقط
echo   %YELLOW%sync%NC%           - مزامنة Capacitor مع Android
echo   %YELLOW%debug%NC%          - بناء APK Debug كامل (Web + Sync + APK)
echo   %YELLOW%release%NC%        - بناء APK Release
echo   %YELLOW%install%NC%        - تثبيت APK على الهاتف
echo   %YELLOW%clean%NC%          - تنظيف المشاريع
echo   %YELLOW%full%NC%           - البناء والتثبيت الكامل
echo.
echo %BLUE%════════════════════════════════════════════════════════════════%NC%
echo   أمثلة الاستخدام:
echo %BLUE%════════════════════════════════════════════════════════════════%NC%
echo.
echo   build-and-deploy.bat debug         - بناء وتثبيت APK Debug
echo   build-and-deploy.bat release       - بناء APK Release
echo   build-and-deploy.bat full          - البناء الكامل
echo   build-and-deploy.bat install       - التثبيت فقط
echo.
echo %BLUE%════════════════════════════════════════════════════════════════%NC%

:end
echo.
pause
