# دليل الإعداد والتثبيت - MVT-VRL Trader

## التثبيت على الويب

### الخطوة 1: متطلبات النظام
- Node.js 16+ [[تحميل](https://nodejs.org/)]
- Git [[تحميل](https://git-scm.com/)]
- متصفح حديث (Chrome, Firefox, Edge)

### الخطوة 2: تثبيت التطبيق

```bash
# استنساخ أو تحميل المشروع
git clone <repository-url>
cd MVT-VRL-Trader

# تثبيت الحزم
npm install

# التشغيل
npm run dev
```

ثم افتح المتصفح على: http://localhost:5173

### الخطوة 3: إعدادات API

#### TwelveData API

```
API Key: 6a1f3b95b77841ceb3beb709fb50763e

الخطوات:
1. اذهب إلى Settings في التطبيق
2. في قسم "API Keys"، اختر TwelveData
3. ضع المفتاح أعلاه
4. فعّل الخيار "Enabled"
5. انقر "Save Settings"
```

#### GitHub Token (اختياري - للمزامنة)

```
1. اذهب إلى https://github.com/settings/tokens
2. انقر "Generate new token (classic)"
3. اختر الصلاحيات:
   - repo (كامل الوصول)
4. نسخ التوكن
5. في التطبيق → GitHub Sync → أدخل التوكن
```

---

## إنشاء و بناء APK

### المتطلبات الإضافية

```bash
# Java Development Kit (JDK 11+)
# تحميل من: https://www.oracle.com/java/technologies/javase-jdk17-downloads.html

# Android SDK
# تحميل من: https://developer.android.com/studio
```

### البناء التلقائي (الطريقة السهلة)

```bash
chmod +x build-apk.sh
./build-apk.sh
```

ملف APK سيكون في: `android/app/build/outputs/apk/debug/app-debug.apk`

### البناء اليدوي

```bash
# 1. بناء الويب
npm run build

# 2. تثبيت Capacitor
npm install @capacitor/core @capacitor/cli @capacitor/android

# 3. إنشاء التطبيق
npx cap init --web-dir=dist

# 4. إضافة Android
npx cap add android

# 5. النسخ والبناء
npx cap sync
cd android
./gradlew assembleDebug
cd ..
```

---

## التثبيت على الهاتف

### باستخدام ADB

```bash
# تثبيت ADB (يأتي مع Android Studio)

# تفعيل وضع المطور على الهاتف:
# 1. إعدادات → عن الهاتف
# 2. اضغط رقم الإصدار 7 مرات
# 3. عد للإعدادات → خيارات المطور
# 4. فعّل "USB Debugging"

# توصيل الهاتف

# تثبيت التطبيق
adb install android/app/build/outputs/apk/debug/app-debug.apk
```

### ملف APK المباشر

```
1. نقل الملف: app-debug.apk إلى الهاتف
2. فتح مدير الملفات
3. الضغط على الملف
4. تثبيت
```

---

## الاستخدام الأول

### 1. إعدادات التداول

```
Settings → Trading Parameters
- Initial Balance: 10000 (أو ما تختار)
- Risk per Trade: 2% (نسبة المخاطرة)
- Active Timeframes: اختر الفريمات
```

### 2. تفعيل API

```
Settings → API Keys
- اختر TwelveData
- ضع المفتاح: 6a1f3b95b77841ceb3beb709fb50763e
- انقر Enable
```

### 3. بدء التداول

```
Live Trading
- Symbol: EURUSD (أو أي زوج عملات)
- Timeframe: اختر الفريم المطلوب
- انقر Start
```

---

## التشغيل بدون إنترنت

```
✅ الرسم البياني يعمل بآخر بيانات محفوظة
✅ الباك تست يعمل 100%
✅ الإحصائيات تعمل
❌ الميزات التي تحتاج إنترنت:
   - تحديث البيانات الحية
   - مزامنة GitHub
```

---

## الملفات المهمة

```
البيانات المحفوظة محلياً:
- trades: الصفقات المحفوظة
- rules: القوانين المكتشفة
- app_settings: الإعدادات
- github_token: توكن GitHub
```

---

## استكشاف الأخطاء

### المشكلة: "Cannot load model"
```
الحل:
1. تحقق من رابط النموذج في Settings
2. تأكد من الاتصال بالإنترنت
3. جرب رابط آخر أو انسخ النموذج محلياً
```

### المشكلة: "API Key not valid"
```
الحل:
1. تأكد من نسخ المفتاح بشكل كامل
2. تحقق من عدم وجود مسافات إضافية
3. جرب إنشاء مفتاح جديد على TwelveData
```

### المشكلة: "No data from API"
```
الحل:
1. تحقق من الرمز (Symbol) - يجب أن يكون صحيح
2. تأكد من اتصالك بالإنترنت
3. جرب رمز آخر معروف (مثل EURUSD)
```

### المشكلة: فشل البناء إلى APK
```
الحل:
1. تحقق من JDK: java -version
2. تحقق من Android SDK: اذهب إلى SDK Manager
3. جرب: cd android && ./gradlew clean
4. ثم: ./gradlew assembleDebug
```

---

## الدعم الإضافي

- توثيق TwelveData: https://twelvedata.com/docs
- توثيق TensorFlow.js: https://www.tensorflow.org/js
- توثيق Capacitor: https://capacitorjs.com/docs

---

**آخر تحديث:** June 2024
**الإصدار:** 1.0.0
